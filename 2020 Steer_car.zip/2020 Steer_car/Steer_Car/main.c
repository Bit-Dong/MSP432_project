#include "sysinit.h"
#include "usart.h"
#include "timA.h"
#include "usart.h"
#include "led.h"
#include "motor.h"
#include "delay.h"
#include "oled.h"
#include "bmp.h"
#include "adc.h"
#include "key4x4.h"
#include "exit.h"
#include "key.h"
#include "sg90.h"
#include "pwm.h"
#include "bluetooth.h"
#include "PID.h"
#include "vofa.h"
#include "hongwai.h"
#include "openmv.h"
#include "beep.h"
#include "gy56.h"

/*                           MSP432P401R
 *
 *	Beep：		 P10.4
 *	Motor:		 P6.4、P6.5(左)        P6.0、P6.1(右) 
 *	OLED:		 P1.7(SCL)			   P1.6(SDA)						-----  IIC
 *	PWM：  		 P2.4(左)			   P2.5(右)       		   			-----  TA0 CH0~CH1
 *  A/B相：		 P5.6、P5.7(左)	   	   P6.6、P6.7(右)          			-----  TA2 CH0~CH1
 *  ADC14:		 P5.5、P5.4、P5.3(该项目未使用)							-----  ADC CH0~CH2  
 *	Vofa:		 P1.2(RX)			   P1.3(TX)							-----  Uart0
 *  BlueTooth：  P2.2(RX)			   P2.3(TX)							-----  Uart1 
 *  GY56:		 P3.2(RX)			   P3.3(TX)							-----  Uart2
 *  OpenMV：	 P9.6(RX)			   P9.7(TX)							-----  Uart3
 *  HongWai:	 P5.3 P9.3 P6.3 P7.2 P7.0 P9.5 P9.7 P7.5 P7.7 P10.1		-----  OUT1~OUT10(左-右)
 *
 */



#define CLKDIV0 48   //时钟源分频   Pwm
#define CLKDIV1 48   //时钟源分频   Timer 
#define CCR0 20000  // 比较值0
#define CCR1 10000  // 比较值1    10ms
#define z 2*3.1415926*0.0325    //轮子周长 0.204203519
#define cn 780             //轮子转动一圈电机输出的脉冲数  13*30*2     单相2倍频计数
#define j z/cn

 /*
	车轮直径65mm 
	减速比 1：30   轮子转一圈，电机转30圈  
	电机转一圈单相输出11个脉冲
	
 */
void Xunji1(void); 
void Xunji2(void); 
void Xunji3(void); 
void Xunji11(void); 
void Xunji12(void); 
void Xunji13(void); 
void Xunji21(void); 
void Xunji22(void); 
void Xunji23(void);
void Xunji31(void); 
void Xunji32(void); 
void Xunji33(void);
int key1_flag=0,key2_flag=0;
int l1,l2,l3;
uint8_t key;
u8 byte[4];
int mode=0;
double Timer=0;
int n=0;
double m=j;    //脉冲数
double s=0,v=0,sum=0;    //路程、速度
int steer;
char openmv_rx;
int stop_flag=0;


//PID相关
PID L_pid,R_pid;
int encoder_L = 0;
int encoder_R = 0;
float target_L=0;
float target_R=0;
float target1_L=0;
float target1_R=0;
int L_out,R_out;

int main(void)
{
    SysInit(); 
	uart_init(115200); 	
	LED_Init();	
    delay_init(); 
    OLED_Init(); 
	KEY_Init();
	Motor_Init();
	BlueTooth_Init();
	OpenMV_Init();
	HongWai_Init();
	TimA2_Cap_Init();
    TimA0_PWM_Init(CCR0,CLKDIV0);
	Stop();
	PID_Init(&L_pid,0,20,30,0);     //0~26
	PID_Init(&R_pid,0,20,30,0);
	SG90_angle(90);                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      
	UART_transmitData(EUSCI_A2_BASE, 'z'); //发送数据
	delay_ms(200);
	
		//显示字符串   0~128   0~6
	OLED_ShowString(30, 0, (uint8_t *)"Bit_Dong", 16);
	OLED_ShowString(8, 2, (uint8_t *)"Angle:", 16);
	OLED_ShowString(80, 2, (uint8_t *)"T:", 16);
	OLED_ShowString(6, 4, (uint8_t *)"Real=      S", 16);
	
	while(1)
	{
		l3=gpio_get(GPIO_PORT_P10, GPIO_PIN5);		
		key=KEY_Scan(0);
		if (key == KEY1_PRES)
		{
			delay_ms(100);
			key1_flag++;			
		}
		else if(key==KEY2_PRES)
		{
			delay_ms(100);
			key2_flag++;
		}

		if(l3==0)
		{
			LED_RED_On();
			break;
		}		
		
		if(key1_flag==0)  //表示 0° 
		{			
			//OLED_ShowNum(52,2,0,2,16);
			if(key2_flag==1)  // 5s
			{
				OLED_ShowNum(96,2,5,1,16);
				mode=1;
			}
			else if(key2_flag==2)  // 7s
			{
				OLED_ShowNum(96,2,7,1,16);
				mode=2;
			}
			else if(key2_flag==3)  // 9s
			{
				OLED_ShowNum(96,2,9,1,16);
				mode=3;
			}
		}
		else if(key1_flag==1)  //表示 10° 
		{
			OLED_ShowNum(52,2,10,2,16);
			if(key2_flag==1)  // 5s
			{
				OLED_ShowNum(96,2,5,1,16);
				mode=11;
			}
			else if(key2_flag==2)  // 7s
			{
				OLED_ShowNum(96,2,7,1,16);
				mode=12;
			}
			else if(key2_flag==3)  // 9s
			{
				OLED_ShowNum(96,2,9,1,16);
				mode=13;
			}
		}
		else if(key1_flag==2)  //表示 20° 
		{
			OLED_ShowNum(52,2,20,2,16);
			if(key2_flag==1)  // 5s
			{
				OLED_ShowNum(96,2,5,1,16);
				mode=21;
			}
			else if(key2_flag==2)  // 7s
			{
				OLED_ShowNum(96,2,7,1,16);
				mode=22;
			}
			else if(key2_flag==3)  // 9s
			{
				OLED_ShowNum(96,2,9,1,16);
				mode=23;
			}
		}
		else if(key1_flag==3)  //表示 30° 
		{
			OLED_ShowNum(52,2,30,2,16);
			if(key2_flag==1)  // 5s
			{
				OLED_ShowNum(96,2,5,1,16);
				mode=31;
			}
			else if(key2_flag==2)  // 7s
			{
				OLED_ShowNum(96,2,7,1,16);
				mode=32;
			}
			else if(key2_flag==3)  // 9s
			{
				OLED_ShowNum(96,2,9,1,16);
				mode=33;
			}
		}

		
	}
	TimA1_Int_Init(CCR1,CLKDIV1);
	Forward();
	PID_Init(&L_pid,10,20,30,0);     //0~26
	PID_Init(&R_pid,10,20,30,0);	
    while (1)
    {						
		l1=gpio_get(GPIO_PORT_P8, GPIO_PIN6);
		l2=gpio_get(GPIO_PORT_P8, GPIO_PIN7);
		if(l1==1&&l2==1&&sum>=0.5)
		{	
			LED_RED_On();
			TimerA1_Disable();
			OLED_ShowNum(47,4,(int)Timer,2,16);
			delay_ms(50);
			int t=(int)(Timer*10)%10;
			OLED_ShowNum(63,4,t,3,16);
			delay_ms(50);
			SG90_angle(90);
			while(1)
			{		
				Stop();
				PID_SetPoint(&L_pid,0);
				PID_SetPoint(&R_pid,0);
				delay_ms(100);															
			}		
		}
		
		if(mode==1)
		{
			Xunji1();
		}
		else if(mode==2)
		{
			Xunji2();
		}
		else if(mode==3)
		{
			Xunji3();
		}
		else if(mode==11)
		{
			Xunji11();
		}
		else if(mode==12)
		{
			Xunji12();
		}
		else if(mode==13)
		{
			Xunji13();
		}
		else if(mode==21)
		{
			Xunji21();
		}
		else if(mode==22)
		{
			Xunji22();
		}
		else if(mode==23)
		{
			Xunji23();
		}
		else if(mode==31)
		{
			Xunji31();
		}
		else if(mode==32)
		{
			Xunji32();
		}
		else if(mode==33)
		{
			Xunji33();
		}		
	}
}



void TA1_0_IRQHandler(void)
{
    MAP_Timer_A_clearCaptureCompareInterrupt(TIMER_A1_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_0);	
	n++;
	Timer=0.01*n;
	s=(encoder_L+encoder_R)/2*m;
//	v=s*100;      // v=s/t   t=10ms=0.01s
	sum+=s;	
	//SendDatatoVoFA(byte,encoder_R,encoder_L);
	//SendData(byte,encoder_L);
	L_out=Position_PID_Cal(&L_pid,encoder_L);
	R_out=Position_PID_Cal(&R_pid,encoder_R);
	MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, L_out);
	MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, R_out);
	encoder_L=0;
	encoder_R=0;		
}

void TA2_N_IRQHandler(void)
{
    uint_fast16_t status = MAP_Timer_A_getCaptureCompareEnabledInterruptStatus(TIMER_A2_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1);
    if (status & TIMER_A_CAPTURECOMPARE_INTERRUPT_FLAG)
    {
//		if(GPIO_getInputPinValue(GPIO_PORT_P5, GPIO_PIN6) == 1 && GPIO_getInputPinValue(GPIO_PORT_P6, GPIO_PIN6) == 1)
//			encoder_L--; // 每次捕获增加编码器计数值
//		else if(GPIO_getInputPinValue(GPIO_PORT_P5, GPIO_PIN6) == 1 && GPIO_getInputPinValue(GPIO_PORT_P6, GPIO_PIN6) == 0)
//			encoder_L++; // 每次捕获增加编码器计数值
//		else if(GPIO_getInputPinValue(GPIO_PORT_P5, GPIO_PIN6) == 0 && GPIO_getInputPinValue(GPIO_PORT_P6, GPIO_PIN6) == 1)
//			encoder_L++; // 每次捕获增加编码器计数值
//		else if(GPIO_getInputPinValue(GPIO_PORT_P5, GPIO_PIN6) == 0 && GPIO_getInputPinValue(GPIO_PORT_P6, GPIO_PIN6) == 0)
//			encoder_L--; // 每次捕获增加编码器计数值
		encoder_L++;
        MAP_Timer_A_clearCaptureCompareInterrupt(TIMER_A2_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1);
    }
	
	uint_fast16_t status2 = MAP_Timer_A_getCaptureCompareEnabledInterruptStatus(TIMER_A2_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2);
    if (status2 & TIMER_A_CAPTURECOMPARE_INTERRUPT_FLAG)
    {
//		if(GPIO_getInputPinValue(GPIO_PORT_P5, GPIO_PIN7) == 1 && GPIO_getInputPinValue(GPIO_PORT_P6, GPIO_PIN7) == 1)
//			encoder_R--; // 每次捕获增加编码器计数值
//		else if(GPIO_getInputPinValue(GPIO_PORT_P5, GPIO_PIN7) == 1 && GPIO_getInputPinValue(GPIO_PORT_P6, GPIO_PIN7) == 0)
//			encoder_R++; // 每次捕获增加编码器计数值
//		else if(GPIO_getInputPinValue(GPIO_PORT_P5, GPIO_PIN7) == 0 && GPIO_getInputPinValue(GPIO_PORT_P6, GPIO_PIN7) == 1)
//			encoder_R++; // 每次捕获增加编码器计数值
//		else if(GPIO_getInputPinValue(GPIO_PORT_P5, GPIO_PIN7) == 0 && GPIO_getInputPinValue(GPIO_PORT_P6, GPIO_PIN7) == 0)
//			encoder_R--; // 每次捕获增加编码器计数值
		encoder_R++;
        MAP_Timer_A_clearCaptureCompareInterrupt(TIMER_A2_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2);
    }
	
}



//OpenMV
void EUSCIA2_IRQHandler(void)
{
    uint32_t status = UART_getEnabledInterruptStatus(EUSCI_A2_BASE);

    if(status & EUSCI_A_UART_RECEIVE_INTERRUPT_FLAG) //接收中断
    {
		openmv_rx=MAP_UART_receiveData(EUSCI_A2_BASE);
		if( openmv_rx=='S' && sum>=0.6)
		{
			stop_flag=1;
		}
    }
	UART_disableInterrupt(EUSCI_A2_BASE, EUSCI_A_UART_RECEIVE_INTERRUPT);   //关闭接收中断
}

void Xunji1(void)  // 0°  5s
{
	Forward();

	if( openmv_rx=='F' )
	{
		steer=90;
		target_L=7;
		target_R=7;	
	}	
	//偏向左边
	else if( openmv_rx=='a' )
	{
		steer=100;	
		target_L=7;
		target_R=8;			
	}
	else if( openmv_rx=='0' )
	{
		steer=110;	
		target_L=7;
		target_R=9;			
	}
	else if( openmv_rx=='1' )
	{
		steer=140;
		target_L=7;
		target_R=10;			
	}
	else if( openmv_rx=='2' )
	{
		steer=160;
		target_L=6;
		target_R=11;				
	}
	else if( openmv_rx=='3' )
	{
		steer=180;
		target_L=5;
		target_R=12;				
	}
	else if( openmv_rx=='4' )
	{
		steer=180;
		target_L=4;
		target_R=12;				
	}
	
	//偏向右边
	else if( openmv_rx=='b' )
	{
		steer=80;
		target_L=8;
		target_R=7;			
	}
	else if( openmv_rx=='5' )
	{
		steer=60;
		target_L=9;
		target_R=7;			
	}
	else if( openmv_rx=='6' )
	{
		steer=40;
		target_L=9;
		target_R=6;			
	}
	
	else
	{
		PID_SetPoint(&L_pid,target_L);
		PID_SetPoint(&R_pid,target_R);	
		SG90_angle(steer);
	}		
	PID_SetPoint(&L_pid,target_L);
	PID_SetPoint(&R_pid,target_R);	
	SG90_angle(steer);
	UART_enableInterrupt(EUSCI_A2_BASE, EUSCI_A_UART_RECEIVE_INTERRUPT);    //开启接收中断 
}

void Xunji2(void)   // 0° 7s
{
	Forward();

	if( openmv_rx=='F' )
	{
		steer=90;
		target_L=5;
		target_R=5;		
	}	

	//偏向左边
	else if( openmv_rx=='a' )
	{
		steer=100;	
		target_L=4;
		target_R=5;		
	}
	else if( openmv_rx=='0' )
	{
		steer=110;	
		target_L=4;
		target_R=6;		
	}
	else if( openmv_rx=='1' )
	{
		steer=140;
		target_L=5;
		target_R=8;			
	}
	else if( openmv_rx=='2' )
	{
		steer=160;
		target_L=5;
		target_R=10;			
	}
	else if( openmv_rx=='3' )
	{
		steer=180;
		target_L=4;
		target_R=10;			
	}
	else if( openmv_rx=='4' )
	{
		steer=180;
		target_L=3;
		target_R=10;		
	}
	
	//偏向右边
	else if( openmv_rx=='b' )
	{
		steer=80;
		target_L=6;
		target_R=5;			
	}
	else if( openmv_rx=='5' )
	{
		steer=60;
		target_L=7;
		target_R=5;			
	}
	else if( openmv_rx=='6' )
	{
		steer=40;
		target_L=7;
		target_R=4;			
	}

	else
	{
		PID_SetPoint(&L_pid,target_L);
		PID_SetPoint(&R_pid,target_R);	
		SG90_angle(steer);
	}
	PID_SetPoint(&L_pid,target_L);
	PID_SetPoint(&R_pid,target_R);
	SG90_angle(steer);	
	UART_enableInterrupt(EUSCI_A2_BASE, EUSCI_A_UART_RECEIVE_INTERRUPT);    //开启接收中断 
}


void Xunji3(void)   // 0° 8s
{
	Forward();

	if( openmv_rx=='F' )
	{
		steer=90;
		target_L=3;
		target_R=3;		
	}	

	//偏向左边
	else if( openmv_rx=='a' )
	{
		steer=100;	
		target_L=3;
		target_R=3;		
	}
	else if( openmv_rx=='0' )
	{
		steer=110;	
		target_L=4;
		target_R=5;		
	}
	else if( openmv_rx=='1' )
	{
		steer=140;
		target_L=4;
		target_R=6;			
	}
	else if( openmv_rx=='2' )
	{
		steer=160;
		target_L=4;
		target_R=7;			
	}
	else if( openmv_rx=='3' )
	{
		steer=180;
		target_L=3;
		target_R=8;			
	}
	else if( openmv_rx=='4' )
	{
		steer=180;
		target_L=3;
		target_R=10;		
	}
	
	//偏向右边
	else if( openmv_rx=='b' )
	{
		steer=80;
		target_L=5;
		target_R=4;			
	}
	else if( openmv_rx=='5' )
	{
		steer=60;
		target_L=5;
		target_R=3;			
	}
	else if( openmv_rx=='6' )
	{
		steer=40;
		target_L=6;
		target_R=3;			
	}

	else
	{
		PID_SetPoint(&L_pid,target_L);
		PID_SetPoint(&R_pid,target_R);	
		SG90_angle(steer);
	}
	PID_SetPoint(&L_pid,target_L);
	PID_SetPoint(&R_pid,target_R);
	SG90_angle(steer);	
	UART_enableInterrupt(EUSCI_A2_BASE, EUSCI_A_UART_RECEIVE_INTERRUPT);    //开启接收中断 
}

void Xunji11(void)
{
	Forward();

	if( openmv_rx=='F' )
	{
		steer=90;
		target_L=4;
		target_R=4;		
	}	

	//偏向左边
	else if( openmv_rx=='a' )
	{
		steer=100;	
		target_L=4;
		target_R=4;		
	}
	else if( openmv_rx=='0' )
	{
		steer=110;	
		target_L=3;
		target_R=4;		
	}
	else if( openmv_rx=='1' )
	{
		steer=140;
		target_L=3;
		target_R=5;			
	}
	else if( openmv_rx=='2' )
	{
		steer=160;
		target_L=3;
		target_R=6;			
	}
	else if( openmv_rx=='3' )
	{
		steer=180;
		target_L=3;
		target_R=8;			
	}
	else if( openmv_rx=='4' )
	{
		steer=180;
		target_L=3;
		target_R=10;		
	}
	
	//偏向右边
	else if( openmv_rx=='b' )
	{
		steer=80;
		target_L=5;
		target_R=4;			
	}
	else if( openmv_rx=='5' )
	{
		steer=60;
		target_L=5;
		target_R=3;			
	}
	else if( openmv_rx=='6' )
	{
		steer=40;
		target_L=6;
		target_R=3;			
	}

	else
	{
		PID_SetPoint(&L_pid,target_L);
		PID_SetPoint(&R_pid,target_R);	
		SG90_angle(steer);
	}
	PID_SetPoint(&L_pid,target_L);
	PID_SetPoint(&R_pid,target_R);
	SG90_angle(steer);	
	UART_enableInterrupt(EUSCI_A2_BASE, EUSCI_A_UART_RECEIVE_INTERRUPT);    //开启接收中断  
}

void Xunji12(void)
{
	Forward();

	if( openmv_rx=='F' )
	{
		steer=90;
		target_L=4;
		target_R=4;		
	}	

	//偏向左边
	else if( openmv_rx=='a' )
	{
		steer=100;	
		target_L=4;
		target_R=4;		
	}
	else if( openmv_rx=='0' )
	{
		steer=110;	
		target_L=3;
		target_R=4;		
	}
	else if( openmv_rx=='1' )
	{
		steer=140;
		target_L=3;
		target_R=5;			
	}
	else if( openmv_rx=='2' )
	{
		steer=160;
		target_L=3;
		target_R=6;			
	}
	else if( openmv_rx=='3' )
	{
		steer=180;
		target_L=3;
		target_R=8;			
	}
	else if( openmv_rx=='4' )
	{
		steer=180;
		target_L=3;
		target_R=10;		
	}
	
	//偏向右边
	else if( openmv_rx=='b' )
	{
		steer=80;
		target_L=5;
		target_R=4;			
	}
	else if( openmv_rx=='5' )
	{
		steer=60;
		target_L=5;
		target_R=3;			
	}
	else if( openmv_rx=='6' )
	{
		steer=40;
		target_L=6;
		target_R=3;			
	}

	else
	{
		PID_SetPoint(&L_pid,target_L);
		PID_SetPoint(&R_pid,target_R);	
		SG90_angle(steer);
	}
	PID_SetPoint(&L_pid,target_L);
	PID_SetPoint(&R_pid,target_R);
	SG90_angle(steer);	
	UART_enableInterrupt(EUSCI_A2_BASE, EUSCI_A_UART_RECEIVE_INTERRUPT);    //开启接收中断 
}

void Xunji13(void)
{

}

void Xunji21(void)
{

}

void Xunji22(void)
{

}

void Xunji23(void)
{

}

void Xunji31(void)
{

}

void Xunji32(void)
{

}

void Xunji33(void)
{

}

