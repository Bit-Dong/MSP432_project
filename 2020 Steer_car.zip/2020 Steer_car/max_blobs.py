# Single Color RGB565 Blob Tracking Example
#
# This example shows off single color RGB565 tracking using the OpenMV Cam.

import sensor, image, time, math, pyb, json

from image import SEARCH_EX, SEARCH_DS
from pyb import UART



uart = UART(3, 115200)


threshold_index = 0 # 0 for red, 1 for green, 2 for blue


thresholds = [(42, 0, -128, 127, -90, 127), # 黑  色块阈值选择
              (70, 20, 14, 127, -128, 127), # 红
              (0, 30, 0, 64, -128, 0)]

sensor.reset()     #摄像头重置
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)   # 设置分辨率大小
sensor.skip_frames(time = 2000)
sensor.set_auto_gain(False) # must be turned off for color tracking
sensor.set_auto_whitebal(False) # must be turned off for color tracking
clock = time.clock()
ROI1=(0,75,320,90)   #感应区域设置
data='0'


#在给定的色块列表中寻找1个最大的色块，ID存在max_ID中，便于调用
def find_max(blobs):
    max_size=0
    for blob in blobs:
        if blob[2]*blob[3] > max_size:
            max_blob=blob
            max_size = blob[2]*blob[3]
    return max_blob


def car_run(err):
    if(err>158 and err<162):
        uart.write("F")

    elif(err>=150 and err<=158):
        uart.write("a")
    elif(err>=120 and err<150):
        uart.write("0")
    elif(err>=90 and err<120):
        uart.write("1")
    elif(err>=60 and err<90):
        uart.write("2")
    elif(err>=30 and err<60):
        uart.write("3")
    elif(err>=0 and err<30):
        uart.write("4")

    elif(err>=162 and err<170):
        uart.write("b")
    elif(err>=170 and err<200):
        uart.write("5")
    elif(err>=200 and err<230):
        uart.write("6")
    elif(err>=230 and err<260):
        uart.write("7")
    elif(err>=260 and err<290):
        uart.write("8")
    elif(err>=290 and err<320):
        uart.write("9")


while(True):
    clock.tick()
    img = sensor.snapshot()  #截取摄像头的一个图像
    img.draw_rectangle(ROI1)  #给感应区画矩形
    if uart.any():
        data=uart.readline().decode().strip()  #转化为字符串接收
    if data=='z':
        data='0'
        w=0
    blob=img.find_blobs([thresholds[0]], roi=ROI1, x_stride=10, y_stride=5,pixels_threshold=10, area_threshold=10, merge=True)   #模板匹配函数
    if blob:
        max_ID=[-1]
        max_ID=find_max(blob)  #找最大色块
        img.draw_rectangle(max_ID.rect())
        img.draw_cross(max_ID.cx(),max_ID.cy())


        #print('x='+str(blob.cx())+'  y='+str(blob.cy()))
        x=max_ID.cx()
        w=max_ID.w()   #5cm -- 85
        #print(max_ID.area())
        #print(x)  # 40~280
        #print(w)
        if w>=80:
            uart.write("S")
        else:
            car_run(x)

