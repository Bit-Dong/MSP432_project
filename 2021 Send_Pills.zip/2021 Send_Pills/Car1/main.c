#include "sysinit.h"
#include "usart.h"
#include "timA.h"
#include "usart.h"
#include "led.h"
#include "motor.h"
#include "delay.h"
#include "oled.h"
#include "bmp.h"
#include "adc.h"
#include "key4x4.h"
#include "exit.h"
#include "key.h"
#include "sg90.h"
#include "pwm.h"
#include "bluetooth.h"
#include "PID.h"
#include "vofa.h"
#include "hongwai.h"
#include "openmv.h"

/*                           MSP432P401R
 *  碰撞器：	 P7.7
 *	Uart0:		 P1.2(RX)			   P1.3(TX)	
 *	Motor:		 P6.4、P6.5(左)        P6.0、P6.1(右) 
 *	PWM：  		 P2.4(左)			   P2.5(右)       		    -----  TA0 CH0~CH1
 *  A/B相：		 P5.6(左)	   	       P5.7(右)          		-----  TA2 CH0~CH1
 *  BlueTooth：  P2.2(RX) 			   P2.3(TX)					-----  Uart1
 *	OLED:		 P1.7(SCL)			   P1.6(SDA)				-----  IIC
 *  ADC14:		 P5.5、P5.4、P5.3								-----  CH0~CH2   
 *  OpenMV:		 P3.2(RX)			   P3.3(TX)					-----  Uart2
 *  HongWai:	 P8.6~P7.5	  									-----  OUT1~OUT12 
 */



#define CLKDIV0 48   //时钟源分频   Pwm
#define CLKDIV1 48   //时钟源分频   Timer 
#define CCR0 1000  // 比较值0
#define CCR1 10000  // 比较值1    10ms

#define z 2*3.1415926*0.0325    //轮子周长 0.204203519
#define cn 1170              //轮子转动一圈电机输出的脉冲数  13*45*2     单相2倍频计数
#define j z/cn

 /*
	车轮直径65mm 
	减速比 1：45   轮子转一圈，电机转45圈  
	电机转一圈单相输出13个脉冲
 */
 
void XunXian(void);
void Lukou1(void);
void Lukou2(void);
void Lukou3(void);
void Lukou4(void);
void Lukou5(void);

int L_out,R_out;
int encoder_L = 0;
int encoder_R = 0;


int uart_enable_flag=0;
int lukou4_flag=0,lukou5_flag=0;
int button_flag=0;
int l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12;
int uart_flag=0;
int n=0;
double m=j;    //脉冲数
double s=0,v=0,sum=0;    //路程、速度
int sum_flag=0,openmv_rxflag=0;
char openmv_rx;
int LR_flag=-1;
int Timer=0;
int t=0;
int room1_flag=0,room2_flag=0,room3_flag=0,room4_flag=0,room5_flag=0,room6_flag=0,room7_flag=0,room8_flag=0;
int over=0;
int stop_flag=0;

int main(void)
{
    SysInit(); 
	uart_init(115200); 	
	LED_Init();	
    delay_init(); 
    OLED_Init(); 
	KEY_Init();
	Motor_Init();
	HongWai_Init();
	BlueTooth_Init();
	OpenMV_Init();

	TimA2_Cap_Init();
    TimA0_PWM_Init(CCR0,CLKDIV0);
	TimA1_Int_Init(CCR1,CLKDIV1);                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           
	
	UART_transmitData(EUSCI_A2_BASE, '8');  //重启OpenMV指令		
	OLED_ShowString(30, 0, (uint8_t *)"Bit_Dong", 16);  //显示字符串   0~128   0~6	
	while(!openmv_rxflag)
	{
		Stop();
	}
		
	OLED_ShowString(30, 2, (uint8_t *)"Room:", 16);
	OLED_ShowNum(70,2,openmv_rxflag,1,16);
	while(gpio_get(GPIO_PORT_P7, GPIO_PIN7))
	{
		LED_RED_On();
	}
	LED_RED_Off();	
	Forward();
	MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 350);
	MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 330);	
	delay_ms(200);
    while (1)
    {	
		l1=gpio_get(GPIO_PORT_P8, GPIO_PIN6);
		l2=gpio_get(GPIO_PORT_P8, GPIO_PIN7);
		l3=gpio_get(GPIO_PORT_P9, GPIO_PIN1);
		l4=gpio_get(GPIO_PORT_P8, GPIO_PIN3);
		l5=gpio_get(GPIO_PORT_P5, GPIO_PIN3);
		l6=gpio_get(GPIO_PORT_P9, GPIO_PIN3);
		l7=gpio_get(GPIO_PORT_P6, GPIO_PIN3);
		l8=gpio_get(GPIO_PORT_P7, GPIO_PIN2);
		l9=gpio_get(GPIO_PORT_P7, GPIO_PIN0);
		l10=gpio_get(GPIO_PORT_P9, GPIO_PIN5);
		l11=gpio_get(GPIO_PORT_P9, GPIO_PIN7);
		l12=gpio_get(GPIO_PORT_P7, GPIO_PIN5);
		
		XunXian();
		if(openmv_rxflag==1||openmv_rxflag==2)
		{
			Lukou1();
		}
		else if(LR_flag==1||LR_flag==2||LR_flag==3||LR_flag==11||LR_flag==22)
		{
			Lukou2();
		}
		else if(LR_flag==4||LR_flag==5)
		{
			Lukou3();
		}
		else if(lukou4_flag==1)
		{
			Lukou4();
		}
		else if(lukou5_flag==1)
		{
			Lukou5();
		}
		
		if(sum>=1.35 && sum_flag==0 && openmv_rxflag>=3)
		{
//			printf("%.2f\r\n",sum);
			sum_flag=1;		
			uart_enable_flag=1;
			Stop();	
			while(1)
			{
				LED_RED_On();
				UART_transmitData(EUSCI_A2_BASE, '1');
				delay_ms(500);
				LED_RED_Off();
				if(uart_enable_flag==1)
				{
					uart_enable_flag=0;
					UART_enableInterrupt(EUSCI_A2_BASE, EUSCI_A_UART_RECEIVE_INTERRUPT);
				}								
				if((openmv_rx=='L'||openmv_rx=='R'||openmv_rx=='F'))  break;
			}
			UART_transmitData(EUSCI_A2_BASE, '9');
			delay_ms(500);
			OLED_ShowChar(110,0,openmv_rx,16);
			Forward();
			MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 400);
			MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 380);				
		}
		
		if(sum>=2.3 && LR_flag==33)
		{
			//printf("%.2f\r\n",sum);
			uart_enable_flag=1;
			Stop();			
			while(1)
			{
				LED_RED_On();
				UART_transmitData(EUSCI_A2_BASE, '2');
				delay_ms(500);
				if(uart_enable_flag==1)
				{
					uart_enable_flag=0;
					UART_enableInterrupt(EUSCI_A2_BASE, EUSCI_A_UART_RECEIVE_INTERRUPT);
				}
				LED_RED_Off();
				if((openmv_rx=='l'||openmv_rx=='r'))  break;
			}
			UART_transmitData(EUSCI_A2_BASE, '9');
			delay_ms(500);
			OLED_ShowChar(110,2,openmv_rx,16);
			Forward();
			MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 400);
			MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 380);	
		}

		if(sum>=3.35 && (LR_flag==44))
		{
			lukou4_flag=1;
			uart_enable_flag=1;
			//printf("%.2f\r\n",sum);
			Stop();	
			while(1)
			{
				LED_RED_On();
				UART_transmitData(EUSCI_A2_BASE, '3');
				delay_ms(500);
				if(uart_enable_flag==1)
				{
					uart_enable_flag=0;
					UART_enableInterrupt(EUSCI_A2_BASE, EUSCI_A_UART_RECEIVE_INTERRUPT);
				}
				LED_RED_Off();
				if((openmv_rx=='a'||openmv_rx=='b'))  break;
			}
			UART_transmitData(EUSCI_A2_BASE, '9');
			delay_ms(500);
			OLED_ShowChar(110,4,openmv_rx,16);
			Forward();
			MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 400);
			MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 380);	
		}
		else if(sum>=3.4 && (LR_flag==55))
		{
			uart_enable_flag=1;
			lukou5_flag=1;
			//printf("%.2f\r\n",sum);
			Stop();	
			while(1)
			{
				LED_RED_On();
				UART_transmitData(EUSCI_A2_BASE, '3');
				delay_ms(500);
				if(uart_enable_flag==1)
				{
					uart_enable_flag=0;
					UART_enableInterrupt(EUSCI_A2_BASE, EUSCI_A_UART_RECEIVE_INTERRUPT);
				}
				LED_RED_Off();
				if((openmv_rx=='a'||openmv_rx=='b'))  break;
			}
			UART_transmitData(EUSCI_A2_BASE, '9');
			delay_ms(500);
			OLED_ShowChar(110,4,openmv_rx,16);
			Forward();
			MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 400);
			MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 380);	
		}
    }
}


void TA1_0_IRQHandler(void)
{
    MAP_Timer_A_clearCaptureCompareInterrupt(TIMER_A1_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_0);	
	n++;
	Timer=0.01*n;
	s=encoder_L*m;
	sum+=s;
	
	encoder_L=0;			
}


void TA2_N_IRQHandler(void)
{
    uint_fast16_t status = MAP_Timer_A_getCaptureCompareEnabledInterruptStatus(TIMER_A2_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1);
    if (status & TIMER_A_CAPTURECOMPARE_INTERRUPT_FLAG)
    {
        encoder_L++; // 每次捕获增加编码器计数值
		
        MAP_Timer_A_clearCaptureCompareInterrupt(TIMER_A2_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1);
    }
}

//BlueTooth接收中断
void EUSCIA1_IRQHandler(void)
{
    uint32_t status = UART_getEnabledInterruptStatus(EUSCI_A1_BASE);

    if(status & EUSCI_A_UART_RECEIVE_INTERRUPT_FLAG) //接收中断
    {

    }
}


//OpenMV接收中断
void EUSCIA2_IRQHandler(void)
{
    uint32_t status = UART_getEnabledInterruptStatus(EUSCI_A2_BASE);

    if(status & EUSCI_A_UART_RECEIVE_INTERRUPT_FLAG) //接收中断
    {
		uart_flag++;
		openmv_rx=MAP_UART_receiveData(EUSCI_A2_BASE);
        if(openmv_rx=='1')
		{
			openmv_rxflag=1;
		}
		if(openmv_rx=='2')
		{
			openmv_rxflag=2;
		}
        if(openmv_rx=='3')
		{
			openmv_rxflag=3;
		}
        if(openmv_rx=='4')
		{
			openmv_rxflag=4;
		}
        if(openmv_rx=='5')
		{
			openmv_rxflag=5;
		}
        if(openmv_rx=='6')
		{
			openmv_rxflag=6;
		}	
        if(openmv_rx=='7')
		{
			openmv_rxflag=7;
		}	
        if(openmv_rx=='8')
		{
			openmv_rxflag=8;
		}		

/********** 第一个十字路口检测 **********/		
		if(openmv_rx=='L')
		{
			//printf("L");
			LR_flag=1; 
		}	
		if(openmv_rx=='R')
		{
			//printf("R");
			LR_flag=2;  
		}
		if(openmv_rx=='F')
		{
			//printf("F");
			LR_flag=3;		
		}
/********** 第二个十字路口检测 **********/		
		if(openmv_rx=='l')
		{
			//printf("l");
			LR_flag=4;  
		}	
		if(openmv_rx=='r')
		{
			//printf("r");
			LR_flag=5;  
		}
/********** 第三个十字路口检测 **********/		
		if(openmv_rx=='a')
		{
			//printf("a");
			LR_flag=7;  
		}	
		if(openmv_rx=='b')
		{
			//printf("b");
			LR_flag=8;  
		}
//		if(uart_flag==2)
//		{
//			Forward();
//			MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 400);
//			MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 380);	
//		}
		UART_disableInterrupt(EUSCI_A2_BASE, EUSCI_A_UART_RECEIVE_INTERRUPT);   //关闭接收中断
    }

}


void XunXian(void)
{		
	Forward();
	if( l4==0 && l5==0 && (l6==1||l7==1) && l8==0 && l9==0 )
	{
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 400);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 380);			
	}
	//左边
	else if( l4==0 && l5==1 && l6==1 && l7==0 && l8==0 && l9==0 )
	{
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 370);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 380);			
	}
	else if( l4==0 && l5==1 && l6==0 && l7==0 && l8==0 && l9==0 )
	{
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 340);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 380);			
	}		
	else if( l4==1 && l5==1 && l6==0 && l7==0 && l8==0 && l9==0 )
	{
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 300);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 380);					
	}
	else if( l4==1 && l5==0 && l6==0 && l7==0 && l8==0 && l9==0 )
	{
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 150);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 380);			
	}
	
	//右边
	else if( l4==0 && l5==0 && l6==0 && l7==1 && l8==1 && l9==0 )
	{
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 400);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 345);					
	}
	else if( l4==0 && l5==0 && l6==0 && l7==0 && l8==1 && l9==0 )
	{
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 400);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 310);			
	}
	else if( l4==0 && l5==0 && l6==0 && l7==0 && l8==1 && l9==1 )
	{
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 400);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 275);			
	}
	else if( l4==0 && l5==0 && l6==0 && l7==0 && l8==0 && l9==1 )
	{
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 400);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 130);				
	}

}

void Lukou1(void)
{
	
	if(openmv_rxflag==1)
	{		
			//去往1号病房的十字路口左转
		if( (l5==1&&l6==1&&l7==1&&l8==1)&& (room1_flag==0))
		{
			room1_flag=1;
			delay_ms(110);
			Left();
			MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 300);
			MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 280);	
			delay_ms(300);
			while(1)
			{
				l7=gpio_get(GPIO_PORT_P6, GPIO_PIN3);			
				if(l7==1) break;
			}
			stop_flag=1;
		}
		//1号病房回到药房的十字路口右转
		else if( (l5==1&&l6==1&&l7==1&&l8==1) && (room1_flag==2))
		{
			room1_flag=3;
			delay_ms(100);
			Right();
			MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 320);
			MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 280);		
			delay_ms(350);
			while(1)
			{
				l6=gpio_get(GPIO_PORT_P9, GPIO_PIN3);			
				if(l6==1) break;
			}
			over=1;
		}
	}
	
	if(openmv_rxflag==2)
	{
		//去往2号病房的十字路口右转
		if( (l5==1&&l6==1&&l7==1&&l8==1) && (room2_flag==0))
		{
			room2_flag=1;
			delay_ms(100);		
			Right();
			MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 320);
			MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 280);		
			delay_ms(350);
			while(1)
			{
				l6=gpio_get(GPIO_PORT_P9, GPIO_PIN3);			
				if(l6==1) break;
			}
			stop_flag=1;
		}
		//2号病房回到药房的十字路口左转
		else if( (l5==1&&l6==1&&l7==1&&l8==1) && (room2_flag==2))
		{
			room2_flag=3;
			delay_ms(110);
			Left();
			MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 300);
			MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 280);	
			delay_ms(300);
			while(1)
			{
				l7=gpio_get(GPIO_PORT_P6, GPIO_PIN3);			
				if(l7==1) break;
			}
			over=1;
		}		
	}
	
	//1、2号病房停在病房门口
	if((l1==1||l2==1||l11==1||l12==1) && stop_flag==1)
	{		
		stop_flag=2;
		Stop();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 0);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 0);	
		room1_flag=2;
		room2_flag=2;
		button_flag=1;
		while(button_flag)
		{
			button_flag=gpio_get(GPIO_PORT_P7, GPIO_PIN7);
		}
		Back();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 300);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 280);	
		delay_ms(500);
		Left();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 300);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 280);	
		delay_ms(500);
		while(1)
		{
			l7=gpio_get(GPIO_PORT_P6, GPIO_PIN3);			
			if(l7==1) break;
		}		
	}

	//返回到药房门口
	if((l1==1||l2==1||l11==1||l12==1) &&(over==1))
	{
		Stop();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 0);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 0);	
		TimerA1_Disable();
		OLED_ShowString(30, 4, (uint8_t *)"T=    S", 16);
		OLED_ShowNum(47,4,Timer,2,16);
	}		
}


void Lukou2(void)
{
	//接收到openmv发过来的左转标志
	if( (l4==1&&l5==1&&l6==1&&l7==1&&l8==1&&l9==1) && LR_flag==1)
	{
		LR_flag=11;
		//delay_ms(100);
		Left();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 50);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 500);	
		delay_ms(300);
		while(1)
		{
			l7=gpio_get(GPIO_PORT_P6, GPIO_PIN3);
			l8=gpio_get(GPIO_PORT_P7, GPIO_PIN2);			
			if(l7==1&&l8==1) break;
		}
		stop_flag=1;
		room3_flag=1;
	}
	//接收到openmv发过来的右转标志
	else if( (l4==1&&l5==1&&l6==1&&l7==1&&l8==1&&l9==1) && LR_flag==2)
	{
		LR_flag=22;
		delay_ms(100);
		Right();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 320);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 280);		
		delay_ms(350);
		while(1)
		{
			l6=gpio_get(GPIO_PORT_P9, GPIO_PIN3);			
			if(l6==1) break;
		}
		stop_flag=1;
		room4_flag=1;		
	}
	//接收到openmv发过来的直行标志
	else if( (l5==1&&l6==1&&l7==1&&l8==1) && LR_flag==3)
	{
		LR_flag=33;
		Forward();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 400);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 380);		
	}
	else if( (l4==1&&l5==1&&l6==1&&l7==1&&l8==1&&l9==1) && (room3_flag==1))
	{
		room3_flag=2;
		//delay_ms(100);
		Right();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 500);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 0);	
		delay_ms(300);
		while(1)
		{
			l7=gpio_get(GPIO_PORT_P6, GPIO_PIN3);
			l8=gpio_get(GPIO_PORT_P7, GPIO_PIN2);			
			if(l7==1&&l8==1) break;
		}
	}
	else if( (l4==1&&l5==1&&l6==1&&l7==1&&l8==1&&l9==1) && (room4_flag==1))
	{
		room4_flag=2;
		delay_ms(100);
		Left();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 300);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 280);	
		delay_ms(300);
		while(1)
		{
			l7=gpio_get(GPIO_PORT_P6, GPIO_PIN3);			
			if(l7==1) break;
		}
	}
	else if( (l5==1&&l6==1&&l7==1&&l8==1) && (room3_flag==2||room4_flag==2))
	{
		Forward();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 400);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 380);	
		over=1;
	}

	//停在病房门口
	if( (l1==1||l2==1||l11==1||l12==1) && stop_flag==1)
	{		
		stop_flag=2;
		Stop();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 0);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 0);	
		button_flag=1;		
		while(button_flag)
		{
			button_flag=gpio_get(GPIO_PORT_P7, GPIO_PIN7);
		}
		Back();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 300);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 280);	
		delay_ms(500);
		Left();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 300);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 280);	
		delay_ms(500);
		while(1)
		{
			l7=gpio_get(GPIO_PORT_P6, GPIO_PIN3);			
			if(l7==1) break;
		}		
	}
	//返回到药房门口
	else if((l1==1||l2==1||l11==1||l12==1) &&(over==1))
	{
		Stop();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 0);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 0);	
		TimerA1_Disable();
		OLED_ShowString(30, 4, (uint8_t *)"T=    S", 16);
		OLED_ShowNum(47,4,Timer,2,16);
	}	
}

void Lukou3(void)
{
	//接收到openmv发过来的左转标志
	if( (l3==1&&l4==1&&l5==1&&l6==1&&l7==1&&l8==1&&l9==1&&l10==1) && LR_flag==4)
	{
		LR_flag=44;
		delay_ms(100);
		Left();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 300);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 280);	
		delay_ms(200);
		while(1)
		{
			l7=gpio_get(GPIO_PORT_P6, GPIO_PIN3);			
			if(l7==1) break;
		}
	}
	//接收到openmv发过来的右转标志
	else if( (l3==1&&l4==1&&l5==1&&l6==1&&l7==1&&l8==1&&l9==1&&l10==1) && LR_flag==5)
	{
		LR_flag=55;
		delay_ms(100);
		Right();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 320);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 280);		
		delay_ms(250);
		while(1)
		{ 
			l6=gpio_get(GPIO_PORT_P9, GPIO_PIN3);			
			if(l6==1) break;
		}	
	}	
}

void Lukou4(void)
{
	//接收到openmv发过来的左转标志
	if( (l5==1&&l6==1&&l7==1&&l8==1) && LR_flag==7)
	{
		t=Timer;
		delay_ms(100);
		Left();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 300);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 280);	
		delay_ms(200);
		while(1)
		{
			l7=gpio_get(GPIO_PORT_P6, GPIO_PIN3);			
			if(l7==1) break;
		}
		LR_flag=77;
		stop_flag=1;
	}
	//接收到openmv发过来的右转标志
	else if( (l5==1&&l6==1&&l7==1&&l8==1) && LR_flag==8)
	{	
		t=Timer;
		delay_ms(100);
		Right();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 320);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 280);		
		delay_ms(250);
		while(1)
		{
			l6=gpio_get(GPIO_PORT_P9, GPIO_PIN3);			
			if(l6==1) break;
		}
		stop_flag=1;
		LR_flag=88;
	}
	else if( (l4==0&&l8==1&&l9==1&&l10==1) && LR_flag==77)
	{
		delay_ms(130);
		Right();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 320);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 280);		
		delay_ms(250);
		while(1)
		{
			l5=gpio_get(GPIO_PORT_P5, GPIO_PIN3);			
			if(l5==1) break;
		}
		LR_flag=777;
	}
	else if( (l4==0&&l8==1&&l9==1&&l10==1) && LR_flag==777)
	{	
		delay_ms(130);
		Right();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 320);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 280);		
		delay_ms(350);
		while(1)
		{
			l5=gpio_get(GPIO_PORT_P5, GPIO_PIN3);
			l6=gpio_get(GPIO_PORT_P9, GPIO_PIN3);			
			if(l5==1&&l6==1) break;
		}
		LR_flag=7777;
	}
	else if( (l3==1&&l4==1&&l5==1&&l9==0) && LR_flag==88)
	{
		
		delay_ms(130);
		Left();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 300);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 280);		
		delay_ms(200);
		while(1)
		{
			l8=gpio_get(GPIO_PORT_P7, GPIO_PIN2);			
			if(l8==1) break;
		}
		LR_flag=888;
	}
	else if( (l4==0&&l8==1&&l9==1&&l10==1) && LR_flag==888)
	{
		delay_ms(130);
		Right();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 320);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 280);		
		delay_ms(350);
		while(1)
		{
			l5=gpio_get(GPIO_PORT_P5, GPIO_PIN3);
			l6=gpio_get(GPIO_PORT_P9, GPIO_PIN3);			
			if(l5==1&&l6==1) break;
		}
		LR_flag=8888;
	}
	else if( (l4==1&&l5==1&&l6==1&&l7==1&&l8==1&&l9==1) && ((LR_flag==7777)||(LR_flag==8888)))
	{	
		t=Timer;
		Forward();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 400);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 380);
		while(l5==1&&l6==1&&l7==1&&l8==1)
		{
			l5=gpio_get(GPIO_PORT_P5, GPIO_PIN3);
			l6=gpio_get(GPIO_PORT_P9, GPIO_PIN3);
			l7=gpio_get(GPIO_PORT_P6, GPIO_PIN3);
			l8=gpio_get(GPIO_PORT_P7, GPIO_PIN2);			
		}	
		over=1;		
	}
	
	//停在病房门口
	if( (l1==1||l2==1||l11==1||l12==1) && stop_flag==1 && LR_flag==77 && (Timer-t>=3))
	{		
		Stop();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 0);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 0);	
		button_flag=1;		
		while(button_flag)
		{
			button_flag=gpio_get(GPIO_PORT_P7, GPIO_PIN7);
		}
		Back();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 300);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 280);	
		delay_ms(500);
		Left();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 300);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 280);	
		delay_ms(500);
		while(1)
		{
			l8=gpio_get(GPIO_PORT_P7, GPIO_PIN2);			
			if(l8==1) break;
		}
		stop_flag=2;		
	}
	else if( (l1==1||l2==1||l11==1||l12==1) && stop_flag==1 && LR_flag==88)
	{		
		Stop();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 0);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 0);	
		button_flag=1;		
		while(button_flag)
		{
			button_flag=gpio_get(GPIO_PORT_P7, GPIO_PIN7);
		}
		Back();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 300);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 280);	
		delay_ms(500);
		Left();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 300);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 280);	
		delay_ms(500);
		while(1)
		{
			l8=gpio_get(GPIO_PORT_P7, GPIO_PIN2);
			l9=gpio_get(GPIO_PORT_P7, GPIO_PIN0);			
			if(l8==1&&l9==1) break;
		}
		stop_flag=2;		
	}
	//返回到药房门口
	else if((l1==1||l2==1||l11==1||l12==1) &&(over==1) && (Timer-t>=5))
	{
		Stop();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 0);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 0);	
		TimerA1_Disable();
		OLED_ShowString(30, 4, (uint8_t *)"T=    S", 16);
		OLED_ShowNum(47,4,Timer,2,16);
	}	
}

void Lukou5(void)
{
	//接收到openmv发过来的左转标志
	if( (l5==1&&l6==1&&l7==1&&l8==1) && LR_flag==7)
	{
		delay_ms(100);
		Left();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 300);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 280);	
		delay_ms(200);
		while(1)
		{
			l7=gpio_get(GPIO_PORT_P6, GPIO_PIN3);			
			if(l7==1) break;
		}
		LR_flag=77;
		stop_flag=1;
	}
	//接收到openmv发过来的右转标志
	else if( (l5==1&&l6==1&&l7==1&&l8==1) && LR_flag==8)
	{
		delay_ms(100);
		Right();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 320);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 280);		
		delay_ms(250);
		while(1)
		{
			l6=gpio_get(GPIO_PORT_P9, GPIO_PIN3);			
			if(l6==1) break;
		}
		LR_flag=88;
		stop_flag=1;
	}
	else if( (l4==0&&l8==1&&l9==1&&l10==1) && LR_flag==77)
	{
		delay_ms(130);
		Right();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 320);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 280);		
		delay_ms(250);
		while(1)
		{
			l5=gpio_get(GPIO_PORT_P5, GPIO_PIN3);			
			if(l5==1) break;
		}
		LR_flag=777;
	}
	else if( (l4==0&&l8==1&&l9==1&&l10==1) && LR_flag==777)
	{
		delay_ms(130);
		Left();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 300);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 280);		
		delay_ms(200);
		while(1)
		{
			l8=gpio_get(GPIO_PORT_P7, GPIO_PIN2);			
			if(l8==1) break;
		}
		LR_flag=7777;
	}
	else if( (l3==1&&l4==1&&l5==1&&l9==0) && LR_flag==88)
	{
		delay_ms(130);
		Left();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 300);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 280);		
		delay_ms(200);
		while(1)
		{
			l8=gpio_get(GPIO_PORT_P7, GPIO_PIN2);			
			if(l8==1) break;
		}
		LR_flag=888;
	}
	else if( (l4==0&&l8==1&&l9==1&&l10==1) && LR_flag==888)
	{
		delay_ms(130);	
		Left();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 300);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 280);		
		delay_ms(200);
		while(1)
		{
			l8=gpio_get(GPIO_PORT_P7, GPIO_PIN2);			
			if(l8==1) break;
		}
		LR_flag=8888;
	}
	else if( (l5==1&&l6==1&&l7==1&&l8==1) && ((LR_flag==7777)||(LR_flag==8888)))
	{
		Forward();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 400);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 380);
		while(l5==1&&l6==1&&l7==1&&l8==1)
		{
			l5=gpio_get(GPIO_PORT_P5, GPIO_PIN3);
			l6=gpio_get(GPIO_PORT_P9, GPIO_PIN3);
			l7=gpio_get(GPIO_PORT_P6, GPIO_PIN3);
			l8=gpio_get(GPIO_PORT_P7, GPIO_PIN2);			
		}	
		t=Timer;
		over=1;		
	}
	
	//停在病房门口
	if( (l1==1||l2==1||l11==1||l12==1) && stop_flag==1 && LR_flag==77)
	{		
		Stop();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 0);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 0);	
		button_flag=1;		
		while(button_flag)
		{
			button_flag=gpio_get(GPIO_PORT_P7, GPIO_PIN7);
		}
		Back();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 300);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 280);	
		delay_ms(500);
		Left();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 300);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 280);	
		delay_ms(500);
		while(1)
		{
			l7=gpio_get(GPIO_PORT_P6, GPIO_PIN3);			
			if(l7==1) break;
		}		
		stop_flag=2;
	}
	else if( (l1==1||l2==1||l11==1||l12==1) && stop_flag==1 && LR_flag==88)
	{		
		Stop();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 0);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 0);	
		button_flag=1;		
		while(button_flag)
		{
			button_flag=gpio_get(GPIO_PORT_P7, GPIO_PIN7);
		}
		Back();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 300);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 280);	
		delay_ms(500);
		Left();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 300);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 280);	
		delay_ms(500);
		while(1)
		{
			l8=gpio_get(GPIO_PORT_P7, GPIO_PIN2);
			l9=gpio_get(GPIO_PORT_P7, GPIO_PIN0);			
			if(l8==1&&l9==1) break;
		}	
		stop_flag=2;
	}
	//返回到药房门口
	else if((l1==1||l2==1||l11==1||l12==1) &&(over==1) && (Timer-t>=5))
	{
		Stop();
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 0);
		MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 0);	
		TimerA1_Disable();
		OLED_ShowString(30, 4, (uint8_t *)"T=    S", 16);
		OLED_ShowNum(47,4,Timer,2,16);
	}
}

