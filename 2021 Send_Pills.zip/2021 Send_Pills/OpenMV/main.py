import sensor, image, time, os, tf, math, uos, gc, ustruct,utime
from image import SEARCH_EX, SEARCH_DS
from pyb import UART,LED

one=LED(1)
uart = UART(3, 115200)
#uart.write(bytes([0x0a]))
#uart.write("3")

sensor.reset()                         # Reset and initialize the sensor.
sensor.set_pixformat(sensor.RGB565)    # Set pixel format to RGB565 (or GRAYSCALE)
sensor.set_framesize(sensor.QVGA)      # Set frame size to QVGA (320x240)
sensor.set_windowing((280, 240))       # Set 240x240 window.
sensor.skip_frames(time=2000)          # Let the camera adjust.

net = None
labels = None
min_confidence = 0.5
first=0
x=0
flag=0
data='0'
n=0


try:
    # load the model, alloc the model file on the heap if we have at least 64K free after loading
    net = tf.load("trained.tflite", load_to_fb=uos.stat('trained.tflite')[6] > (gc.mem_free() - (64*1024)))
except Exception as e:
    raise Exception('Failed to load "trained.tflite", did you copy the .tflite and labels.txt file onto the mass-storage device? (' + str(e) + ')')

try:
    labels = [line.rstrip('\n') for line in open("labels.txt")]
except Exception as e:
    raise Exception('Failed to load "labels.txt", did you copy the .tflite and labels.txt file onto the mass-storage device? (' + str(e) + ')')

colors = [ # Add more colors if you are detecting more than 7 types of classes at once.
    (255,   0,   0),
    (  0, 255,   0),
    (255, 255,   0),
    (  0,   0, 255),
    (255,   0, 255),
    (  0, 255, 255),
    (255, 255, 255),
    (255, 255, 255),
]

def led_show(num):
    if num is not 0:
        for i in range (num):
            one.on()
            print(num) #使用时删除 给自己看的
            time.sleep_ms(300)
            one.off()
            time.sleep_ms(300)

def get_first_num(img):
    for i, detection_list in enumerate(net.detect(img, thresholds=[(math.ceil(min_confidence * 255), 255)])):
        if (i == 0): continue # background class
        if (len(detection_list) == 0): continue
        if i:
            return i
    return 0

def get_num(img):
    global first
    global x
    for i, detection_list in enumerate(net.detect(img, thresholds=[(math.ceil(min_confidence * 255), 255)])):
        if (i == 0): continue # background class
        if (len(detection_list) == 0): continue
        if i==first and i!=1 and i!=2:
            for d in detection_list:
                [x, y, w, h] = d.rect()
                center_x = math.floor(x + (w / 2))
                center_y = math.floor(y + (h / 2))
                x=center_x
                #print('x %d\ty %d' % (center_x, center_y))
                img.draw_circle((center_x, center_y, 12))
            return x
    return 0

def send_num(num):
    if num==1:
        uart.write("1")
    elif num==2:
        uart.write("2")
    elif num==3:
        uart.write("3")
    elif num==4:
        uart.write("4")
    elif num==5:
        uart.write("5")
    elif num==6:
        uart.write("6")
    elif num==7:
        uart.write("7")
    elif num==8:
        uart.write("8")


clock = time.clock()
while(True):
    clock.tick()

    img = sensor.snapshot()

    if first==0:
        first=get_first_num(img)
        if first:
            send_num(first)

    if uart.any():
        data=uart.readline().decode().strip()  #转化为字符串接收

        if data=='1':
            second=get_num(img)
            if second==0:
                uart.write("F")
                time.sleep_ms(100)
            elif second<=140:
                #print(second)
                uart.write("L")
                time.sleep_ms(100)
            elif second>140:
                #print(second)
                uart.write("R")
                time.sleep_ms(100)

        if data=='2':
            three=get_num(img)
            if three==0:
                three=get_num(img)
            elif three:
                if three<=140:
                    uart.write("l")
                    time.sleep_ms(100)
                elif three>140:
                    uart.write("r")
                    time.sleep_ms(100)

        if data=='3':
            four=get_num(img)
            if four==0:
                four=get_num(img)
            elif four:
                if four<=140:
                    uart.write("a")
                    time.sleep_ms(100)
                elif four>140:
                    uart.write("b")
                    time.sleep_ms(100)

        if data=='8':
            first=0
            data='0'
        if data=='9':
            data='0'
