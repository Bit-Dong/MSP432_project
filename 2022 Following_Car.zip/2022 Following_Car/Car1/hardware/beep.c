#include "beep.h"
#include "motor.h"





void Beep_Init(void)
{
	gpio_init(GPIO_PORT_P10,GPIO_PIN4,0,0); 
}

