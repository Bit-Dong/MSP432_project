#ifndef __GY56_H
#define __GY56_H
#include <ti/devices/msp432p4xx/driverlib/driverlib.h>
#include <stdio.h> //1.61328125kb


#define u8 unsigned char
	
typedef  struct
{
	uint16_t distance;
	uint8_t   mode;
	uint8_t   temp;
}sensor;

void GY56_Init(void);
void gy56_send_com(u8 function,u8 value );
void USART2_Send(uint8_t *Buffer, uint8_t Length);
int Get_distance(void);


#endif
