#ifndef __PWM_H
#define __PWM_H
#include <ti/devices/msp432p4xx/driverlib/driverlib.h>


typedef enum
{
	TA0 ,
	TA1,
	TA2,
	TA3		
} TA_n;
typedef enum
{
	TA_ch0 ,
	TA_ch1,
	TA_ch2,
	TA_ch3,
	TA_ch4,
	TA_ch5
} TA_chn;

#define TA_ch0 TIMER_A_CAPTURECOMPARE_REGISTER_0
#define TA_ch1 TIMER_A_CAPTURECOMPARE_REGISTER_1
#define TA_ch2 TIMER_A_CAPTURECOMPARE_REGISTER_2
#define TA_ch3 TIMER_A_CAPTURECOMPARE_REGISTER_3
#define TA_ch4 TIMER_A_CAPTURECOMPARE_REGISTER_4
#define TA_ch5 TIMER_A_CAPTURECOMPARE_REGISTER_5
#define TA_ch6 TIMER_A_CAPTURECOMPARE_REGISTER_6

void TimA0_PWM_Init(uint16_t ccr0, uint16_t psc);
void Time_A_Pwm_Set(uint16_t  ta_n, uint16_t  ta_chn, uint16_t ccr0, uint16_t duty);


#endif
