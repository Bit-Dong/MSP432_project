#include "sysinit.h"
#include "usart.h"
#include "timA.h"
#include "usart.h"
#include "led.h"
#include "motor.h"
#include "delay.h"
#include "oled.h"
#include "bmp.h"
#include "adc.h"
#include "key4x4.h"
#include "exit.h"
#include "key.h"
#include "sg90.h"
#include "pwm.h"
#include "bluetooth.h"
#include "PID.h"
#include "vofa.h"
#include "hongwai.h"
#include "openmv.h"
#include "beep.h"
#include "gy56.h"

/*                           MSP432P401R
 *
 *	Beep：		 P10.4
 *	Motor:		 P6.4、P6.5(左)        P6.0、P6.1(右) 
 *	OLED:		 P1.7(SCL)			   P1.6(SDA)						-----  IIC
 *	PWM：  		 P2.4(左)			   P2.5(右)       		   			-----  TA0 CH0~CH1
 *  A/B相：		 P5.6(左)	   	       P5.7(右)          				-----  TA2 CH0~CH1
 *  ADC14:		 P5.5、P5.4、P5.3(该项目未使用)							-----  ADC CH0~CH2  
 *	Vofa:		 P1.2(RX)			   P1.3(TX)							-----  Uart0
 *  BlueTooth：  P2.2(RX)			   P2.3(TX)							-----  Uart1 
 *  GY56:		 P3.2(RX)			   P3.3(TX)							-----  Uart2
 *  OpenMV：	 P9.6(RX)			   P9.7(TX)							-----  Uart3
 *  HongWai:	 P5.3 P9.3 P6.3 P7.2 P7.0 P9.5 P9.7 P7.5 P7.7 P10.1		-----  OUT1~OUT10(左-右)
 *
 */



#define CLKDIV0 48   //时钟源分频   Pwm
#define CLKDIV1 48   //时钟源分频   Timer 
#define CCR0 1000  // 比较值0
#define CCR1 10000  // 比较值1    10ms
#define z 2*3.1415926*0.0325    //轮子周长 0.204203519
#define cn 1170              //轮子转动一圈电机输出的脉冲数  13*45*2     单相2倍频计数
#define j z/cn

 /*
	车轮直径65mm 
	减速比 1：45   轮子转一圈，电机转45圈  
	电机转一圈单相输出13个脉冲
 */
void Xunji30(void); 
void Xunji22(void); 
void Xunji50(void); 
int target_L=0;
int target_R=0;
uint8_t key;
int distance=0;
int key_flag=0;
int state_flag=0;
int beep_flag=0;
int distance_flag=0;
int l1,l2,l3,l4,l5,l6,l7,l8,l9,l10;
char blue_rx,blue_tx;
int mode=0;
double Timer=0;
char* oled_Tshow;

int n=0;
int L_out,R_out;
int encoder_L = 0;
int encoder_R = 0;
double m=j;    //脉冲数
double s=0,v=0,sum=0;    //路程、速度

int main(void)
{
    SysInit(); 
	uart_init(115200); 	
	LED_Init();	
    delay_init(); 
    OLED_Init(); 
	KEY_Init();
	Motor_Init();
	HongWai_Init();
	Beep_Init();
	BlueTooth_Init();
	GY56_Init();
	TimA2_Cap_Init();
    TimA0_PWM_Init(CCR0,CLKDIV0);
	
    gy56_send_com(0x76,1);//发送连续输出指令                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       
	Stop();
	
		//显示字符串   0~128   0~6
	OLED_ShowString(30, 0, (uint8_t *)"Bit_Dong", 16);
	OLED_ShowString(30, 2, (uint8_t *)"Mode:", 16);
	
	OLED_ShowString(30, 4, (uint8_t *)"T=      S", 16);
    while (1)
    {			
		key=KEY_Scan(0);
		if (key == KEY1_PRES)
		{
			key=0;
			key_flag++;
			OLED_ShowNum(80,2,key_flag,1,16);			
		}
		else if(key==KEY2_PRES)
		{
			key=0;
			if(key_flag==1)
			{
				mode=1;
				Forward();
				UART_transmitData(EUSCI_A1_BASE, '1'); //发送数据
			}
			else if(key_flag==2)
			{
				mode=2;
				Forward();
				UART_transmitData(EUSCI_A1_BASE, '2'); //发送数据
			}			
			TimA1_Int_Init(CCR1,CLKDIV1);	
		}
		
		int distance=Get_distance();
		if(mode==1)
		{
			Xunji30();
		}
		else if(mode==2 )
		{
			Xunji22();
		}
	}
}



//  Car1: 0.27-0.33m/s  ( 4.78m - 14.5-17.7s )
void Xunji30(void)
{
	l1=gpio_get(GPIO_PORT_P5, GPIO_PIN3);
	l2=gpio_get(GPIO_PORT_P9, GPIO_PIN3);
	l3=gpio_get(GPIO_PORT_P6, GPIO_PIN3);
	l4=gpio_get(GPIO_PORT_P7, GPIO_PIN2);
	l5=gpio_get(GPIO_PORT_P7, GPIO_PIN0);
	l6=gpio_get(GPIO_PORT_P9, GPIO_PIN5);
	l7=gpio_get(GPIO_PORT_P9, GPIO_PIN7);
	l8=gpio_get(GPIO_PORT_P7, GPIO_PIN5);
	l9=gpio_get(GPIO_PORT_P7, GPIO_PIN7);
	l10=gpio_get(GPIO_PORT_P10, GPIO_PIN1);

	
	if(l1==0 && l2==0 && l3==0 && l4==0 && l5==1 && l6==0 && l7==0 && l8==0 && l9==0 && l10==0)
	{
		Forward();
		target_L=365;
		target_R=365;
	}
	else if(l1==0 && l2==0 && l3==0 && l4==0 && l5==0 && l6==1 && l7==0 && l8==0 && l9==0 && l10==0)
	{
		Forward();
		target_L=365;
		target_R=365;
	}
	else if((l1==1&&l4==1)||(l1==1&&l5==1)||(l2==1&&l5==1)||(l2==1&&l6==1)||(l3==1&&6==1)||(l3==1&&l7==1))
	{
		Forward();
		target_L=365;
		target_R=365;
	}
	
//踩左边	
	else if(l1==0 && l2==0 && l3==0 && l4==1 && l5==0 && l6==0 && l7==0 && l8==0 && l9==0 && l10==0 )
	{
		Forward();
		target_L=355;
		target_R=365;		
	}
	else if(l1==0 && l2==0 && l3==1 && l4==0 && l5==0 && l6==0 && l7==0 && l8==0 && l9==0 && l10==0 )
	{
		Forward();
		target_L=345;
		target_R=365;		
	}
	else if(l1==0 && l2==1 && l3==0 && l4==0 && l5==0 && l6==0 && l7==0 && l8==0 && l9==0 && l10==0 && Timer>=1.8)
	{
		Forward();
		target_L=335;
		target_R=365;		
	}		
	else if(l1==1 && l2==0 && l3==0 && l4==0 && l5==0 && l6==0 && l7==0 && l8==0 && l9==0 && l10==0 && Timer>=1.8)
	{	
		Left();
		target_L=0;
		target_R=300;		
	}
	
	//踩右边
	else if(l1==0 && l2==0 && l3==0 && l4==0 && l5==0 && l6==0 && l7==1 && l8==0 && l9==0 && l10==0 )
	{
		Forward();
		target_L=365;
		target_R=355;		
	}
	else if(l1==0 && l2==0 && l3==0 && l4==0 && l5==0 && l6==0 && l7==0 && l8==1 && l9==0 && l10==0 )
	{
		Forward();
		target_L=365;
		target_R=345;		
	}
	else if(l1==0 && l2==0 && l3==0 && l4==0 && l5==0 && l6==0 && l7==0 && l8==0 && l9==1 && l10==0 )
	{
		Forward();
		target_L=365;
		target_R=335;		
	}
	else if(l1==0 && l2==0 && l3==0 && l4==0 && l5==0 && l6==0 && l7==0 && l8==0 && l9==0 && l10==1 )
	{
		Right();
		target_L=300;
		target_R=0;		
	}

//终点停止
	else if(((l2==1&&l3==1&&l4==1)||(l3==1&&l4==1&&l5==1)||(l4==1&&l5==1&&l6==1)||(l5==1&&l6==1&&l7==1)||(l6==1&&l7==1&&l8==1)||(l7==1&&l8==1&&l9==1)) && Timer>=15)
	{
		UART_transmitData(EUSCI_A1_BASE, 's'); //发送数据
		beep_flag++;
		TimerA1_Disable();

		while(1)
		{
			Stop();	
			target_L=0;
			target_R=0;
			MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, target_L);
			MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, target_R);
			
			if(beep_flag==1)
			{
				beep_flag=2;
				OLED_ShowNum(47,4,Timer,2,16);
				int t=(int)(Timer*10)%10;
				OLED_ShowNum(63,4,t,3,16);
				int distance1=Get_distance();
				OLED_ShowString(30, 6, (uint8_t *)"Distance:", 16);
				OLED_ShowNum(100,6,distance1,3,16);
				gpio_set(GPIO_PORT_P10, GPIO_PIN4,1);
				delay_ms(500);
				gpio_set(GPIO_PORT_P10, GPIO_PIN4,0);
			}
		}
	}
	MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, target_L);
	MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, target_R);
}


//  Car2:0.227m/s
void Xunji22(void)
{
	l1=gpio_get(GPIO_PORT_P5, GPIO_PIN3);
	l2=gpio_get(GPIO_PORT_P9, GPIO_PIN3);
	l3=gpio_get(GPIO_PORT_P6, GPIO_PIN3);
	l4=gpio_get(GPIO_PORT_P7, GPIO_PIN2);
	l5=gpio_get(GPIO_PORT_P7, GPIO_PIN0);
	l6=gpio_get(GPIO_PORT_P9, GPIO_PIN5);
	l7=gpio_get(GPIO_PORT_P9, GPIO_PIN7);
	l8=gpio_get(GPIO_PORT_P7, GPIO_PIN5);
	l9=gpio_get(GPIO_PORT_P7, GPIO_PIN7);
	l10=gpio_get(GPIO_PORT_P10, GPIO_PIN1);

	
	if(l1==0 && l2==0 && l3==0 && l4==0 && l5==1 && l6==0 && l7==0 && l8==0 && l9==0 && l10==0)
	{
		Forward();
		target_L=240;
		target_R=250;
	}
	else if(l1==0 && l2==0 && l3==0 && l4==0 && l5==0 && l6==1 && l7==0 && l8==0 && l9==0 && l10==0)
	{
		Forward();
		target_L=240;
		target_R=250;
	}
	else if((l1==1&&l4==1)||(l1==1&&l5==1)||(l2==1&&l5==1)||(l2==1&&l6==1)||(l3==1&&6==1)||(l3==1&&l7==1))
	{
		Forward();
		target_L=240;
		target_R=250;
	}
	
//踩左边	
	else if(l1==0 && l2==0 && l3==0 && l4==1 && l5==0 && l6==0 && l7==0 && l8==0 && l9==0 && l10==0 )
	{
		Forward();
		target_L=240;
		target_R=250;		
	}
	else if(l1==0 && l2==0 && l3==1 && l4==0 && l5==0 && l6==0 && l7==0 && l8==0 && l9==0 && l10==0 )
	{
		Forward();
		target_L=235;
		target_R=250;		
	}
	else if(l1==0 && l2==1 && l3==0 && l4==0 && l5==0 && l6==0 && l7==0 && l8==0 && l9==0 && l10==0 && Timer>=2)
	{
		Forward();
		target_L=230;
		target_R=250;		
	}		
	else if(l1==1 && l2==0 && l3==0 && l4==0 && l5==0 && l6==0 && l7==0 && l8==0 && l9==0 && l10==0 && Timer>=2)
	{	
		Left();
		target_L=0;
		target_R=330;		
	}
	
	//踩右边
	else if(l1==0 && l2==0 && l3==0 && l4==0 && l5==0 && l6==0 && l7==1 && l8==0 && l9==0 && l10==0 )
	{
		Forward();
		target_L=240;
		target_R=245;		
	}
	else if(l1==0 && l2==0 && l3==0 && l4==0 && l5==0 && l6==0 && l7==0 && l8==1 && l9==0 && l10==0 )
	{
		Forward();
		target_L=240;
		target_R=240;		
	}
	else if(l1==0 && l2==0 && l3==0 && l4==0 && l5==0 && l6==0 && l7==0 && l8==0 && l9==1 && l10==0 )
	{
		Forward();
		target_L=240;
		target_R=235;		
	}
	else if(l1==0 && l2==0 && l3==0 && l4==0 && l5==0 && l6==0 && l7==0 && l8==0 && l9==0 && l10==1 )
	{
		Right();
		target_L=330;
		target_R=0;		
	}

//终点停止
	else if(((l2==1&&l3==1&&l4==1)||(l3==1&&l4==1&&l5==1)||(l4==1&&l5==1&&l6==1)||(l5==1&&l6==1&&l7==1)||(l6==1&&l7==1&&l8==1)||(l7==1&&l8==1&&l9==1)) && Timer>=19)
	{
		UART_transmitData(EUSCI_A1_BASE, 's'); //发送数据
		beep_flag++;
		TimerA1_Disable();

		while(1)
		{
			Stop();	
			target_L=0;
			target_R=0;
			MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, target_L);
			MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, target_R);
			
			if(beep_flag==1)
			{
				beep_flag=2;
				OLED_ShowNum(47,4,Timer,2,16);
				int t=(int)(Timer*10)%10;
				OLED_ShowNum(63,4,t,3,16);
				int distance1=Get_distance();
				OLED_ShowString(30, 6, (uint8_t *)"Distance:", 16);
				OLED_ShowNum(100,6,distance1,3,16);
				gpio_set(GPIO_PORT_P10, GPIO_PIN4,1);
				delay_ms(500);
				gpio_set(GPIO_PORT_P10, GPIO_PIN4,0);
			}
		}			
	}
	MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, target_L);
	MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, target_R);
}

// Car2: 0.30m/s
void Xunji50(void)
{
	l1=gpio_get(GPIO_PORT_P5, GPIO_PIN3);
	l2=gpio_get(GPIO_PORT_P9, GPIO_PIN3);
	l3=gpio_get(GPIO_PORT_P6, GPIO_PIN3);
	l4=gpio_get(GPIO_PORT_P7, GPIO_PIN2);
	l5=gpio_get(GPIO_PORT_P7, GPIO_PIN0);
	l6=gpio_get(GPIO_PORT_P9, GPIO_PIN5);
	l7=gpio_get(GPIO_PORT_P9, GPIO_PIN7);
	l8=gpio_get(GPIO_PORT_P7, GPIO_PIN5);
	l9=gpio_get(GPIO_PORT_P7, GPIO_PIN7);
	l10=gpio_get(GPIO_PORT_P10, GPIO_PIN1);

	
	if(l1==0 && l2==0 && l3==0 && l4==0 && l5==1 && l6==0 && l7==0 && l8==0 && l9==0 && l10==0)
	{
		Forward();
		target_L=400;
		target_R=410;
	}
	else if(l1==0 && l2==0 && l3==0 && l4==0 && l5==0 && l6==1 && l7==0 && l8==0 && l9==0 && l10==0)
	{
		Forward();
		target_L=400;
		target_R=410;
	}
	else if(((l1==1&&l4==1)||(l1==1&&l5==1)||(l2==1&&l5==1)||(l2==1&&l6==1)||(l3==1&&6==1)||(l3==1&&l7==1)|| (l3==1&&l2==1)||(l3==1&&l4==1)||(l3==1&&l5==1)||(l4==1&&l5==1)||(l4==1&&l6==1)||(l5==1&&l6==1)||(l5==1&&l7==1)) &&(Timer<=9))
	{
		Forward();
		target_L=400;
		target_R=410;
	}
	
//踩左边	
	else if(l1==0 && l2==0 && l3==0 && l4==1 && l5==0 && l6==0 && l7==0 && l8==0 && l9==0 && l10==0 )
	{
		Forward();
		target_L=400;
		target_R=410;		
	}
	else if(l1==0 && l2==0 && l3==1 && l4==0 && l5==0 && l6==0 && l7==0 && l8==0 && l9==0 && l10==0 )
	{
		Forward();
		target_L=395;
		target_R=410;		
	}
	else if(l1==0 && l2==1 && l3==0 && l4==0 && l5==0 && l6==0 && l7==0 && l8==0 && l9==0 && l10==0 && Timer>=1)
	{
		Forward();
		target_L=390;
		target_R=410;		
	}		
	else if(l1==1 && l2==0 && l3==0 && l4==0 && l5==0 && l6==0 && l7==0 && l8==0 && l9==0 && l10==0 && Timer>=1)
	{	
		Left();
		target_L=0;
		target_R=330;
	}
	
	//踩右边
	else if(l1==0 && l2==0 && l3==0 && l4==0 && l5==0 && l6==0 && l7==1 && l8==0 && l9==0 && l10==0 )
	{
		Forward();
		target_L=400;
		target_R=405;	
	}
	else if(l1==0 && l2==0 && l3==0 && l4==0 && l5==0 && l6==0 && l7==0 && l8==1 && l9==0 && l10==0 )
	{
		Forward();
		target_L=400;
		target_R=400;		
	}
	else if(l1==0 && l2==0 && l3==0 && l4==0 && l5==0 && l6==0 && l7==0 && l8==0 && l9==1 && l10==0 )
	{
		Forward();
		target_L=400;
		target_R=395;		
	}
	else if(l1==0 && l2==0 && l3==0 && l4==0 && l5==0 && l6==0 && l7==0 && l8==0 && l9==0 && l10==1 )
	{
		Right();
		target_L=330;
		target_R=0;		
	}

//终点停止
	else if(((l2==1&&l3==1&&l4==1)||(l3==1&&l4==1&&l5==1)||(l4==1&&l5==1&&l6==1)||(l5==1&&l6==1&&l7==1)||(l6==1&&l7==1&&l8==1)||(l7==1&&l8==1&&l9==1)) && Timer>=12)
	{
		UART_transmitData(EUSCI_A1_BASE, 's'); //发送数据
		beep_flag++;
		TimerA1_Disable();

		while(1)
		{
			Stop();	
			target_L=0;
			target_R=0;
			MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, target_L);
			MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, target_R);
			
			if(beep_flag==1)
			{
				beep_flag=2;
				OLED_ShowNum(47,4,Timer,2,16);
				int t=(int)(Timer*10)%10;
				OLED_ShowNum(63,4,t,3,16);
				int distance1=Get_distance();
				OLED_ShowString(30, 6, (uint8_t *)"Distance:", 16);
				OLED_ShowNum(100,6,distance1,3,16);
				gpio_set(GPIO_PORT_P10, GPIO_PIN4,1);
				delay_ms(500);
				gpio_set(GPIO_PORT_P10, GPIO_PIN4,0);
			}
		}
	}
	MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, target_L);
	MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, target_R);
}

void TA1_0_IRQHandler(void)
{
    MAP_Timer_A_clearCaptureCompareInterrupt(TIMER_A1_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_0);	
	n++;
	Timer=0.01*n;
	//s=(encoder_R+encoder_L)/2*m;
	//v=s*100;      // v=s/t   t=10ms=0.01s
	encoder_L=0;
	encoder_R=0;		
}

void TA2_N_IRQHandler(void)
{
    uint_fast16_t status = MAP_Timer_A_getCaptureCompareEnabledInterruptStatus(TIMER_A2_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1);
    if (status & TIMER_A_CAPTURECOMPARE_INTERRUPT_FLAG)
    {
        encoder_L++; // 每次捕获增加编码器计数值
		
        MAP_Timer_A_clearCaptureCompareInterrupt(TIMER_A2_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1);
    }
	
	uint_fast16_t status2 = MAP_Timer_A_getCaptureCompareEnabledInterruptStatus(TIMER_A2_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2);
    if (status2 & TIMER_A_CAPTURECOMPARE_INTERRUPT_FLAG)
    {
        encoder_R++; // 每次捕获增加编码器计数值

        MAP_Timer_A_clearCaptureCompareInterrupt(TIMER_A2_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2);
    }
}


void EUSCIA1_IRQHandler(void)
{
    uint32_t status = UART_getEnabledInterruptStatus(EUSCI_A1_BASE);

    if(status & EUSCI_A_UART_RECEIVE_INTERRUPT_FLAG) //接收中断
    {
		//blue_rx=MAP_UART_receiveData(EUSCI_A1_BASE);
        
    }

}




