# Single Color RGB565 Blob Tracking Example
#
# This example shows off single color RGB565 tracking using the OpenMV Cam.

import sensor, image, time, math, pyb, json ,sensor
from machine import Pin

from image import SEARCH_EX, SEARCH_DS
from pyb import UART,LED
one=LED(1)


uart = UART(3, 115200)

#green_threshold  = (100, 84, -124, 41, -30, 25) #绿色激光笔

red_threshold  =  (85, 100, -3, 20, -2, 17) # 红色激光笔
back_threshold  = (5, 15, -12, 20, -7, 17)

sensor.reset()     #摄像头重置
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.VGA)   # 设置分辨率大小
sensor.skip_frames(time = 2000)
sensor.set_auto_gain(False) # must be turned off for color tracking
sensor.set_auto_whitebal(False) # must be turned off for color tracking
clock = time.clock()
ROI4=(172,66,319,303)   #感应区域设置
data='0'
n=0
x=0
y=0
x1=0
x2=0
x3=0
x4=0
y1=0
y2=0
y3=0
y4=0
l1=0
l2=0
l3=0
l4=0
err_x=0
err_y=0
target_x=0
target_y=0
flag2=0
flag3=0
flag4=0
flag44=0
send_flag=0

def PaiXun(x11,x22,x33,x44,y11,y22,y33,y44):
    global x1, x2, x3, x4, y1, y2, y3, y4,l1,l2,l3,l4


    if y11<y22 and y11<y33 and y11<y44:
        x1=x11
        y1=y11
        if x22>x33 and x22>x44:
            x2=x22
            y2=y22
            if x33>x44:
                x3=x33
                y3=y33
                x4=x44
                y4=y44
            else:
                x3=x44
                y3=y44
                x4=x33
                y4=y33
        elif x33>x22 and x33>x44:
            x2=x33
            y2=y33
            if x22>x44:
                x3=x22
                y3=y22
                x4=x44
                y4=y44
            else:
                x3=x44
                y3=y44
                x4=x22
                y4=y22
        elif x44>x22 and x44>x33:
            x2=x44
            y2=y44
            if x22>x33:
                x3=x22
                y3=y22
                x4=x33
                y4=y33
            else:
                x3=x33
                y3=y33
                x4=x22
                y4=y22

    elif y22<y11 and y22<y33 and y22<y44:
        x1=x22
        y1=y22
        if x11>x33 and x11>x44:
            x2=x11
            y2=y11
            if x33>x44:
                x3=x33
                y3=y33
                x4=x44
                y4=y44
            else:
                x3=x44
                y3=y44
                x4=x33
                y4=y33
        elif x33>x11 and x33>x44:
            x2=x33
            y2=y33
            if x11>x44:
                x3=x11
                y3=y11
                x4=x44
                y4=y44
            else:
                x3=x44
                y3=y44
                x4=x11
                y4=y11
        elif x44>x11 and x44>x33:
            x2=x44
            y2=y44
            if x11>x33:
                x3=x11
                y3=y11
                x4=x33
                y4=y33
            else:
                x3=x33
                y3=y33
                x4=x11
                y4=y11

    elif y33<y11 and y33<y22 and y33<y44:
        x1=x33
        y1=y33
        if x11>x22 and x11>x44:
            x2=x11
            y2=y11
            if x22>x44:
                x3=x22
                y3=y22
                x4=x44
                y4=y44
            else:
                x3=x44
                y3=y44
                x4=x22
                y4=y22
        elif x22>x11 and x22>x44:
            x2=x22
            y2=y22
            if x11>x44:
                x3=x11
                y3=y11
                x4=x44
                y4=y44
            else:
                x3=x44
                y3=y44
                x4=x11
                y4=y11
        elif x44>x11 and x44>x22:
            x2=x44
            y2=y44
            if x11>x22:
                x3=x11
                y3=y11
                x4=x22
                y4=y22
            else:
                x3=x22
                y3=y22
                x4=x11
                y4=y11

    else:
        x1=x44
        y1=y44
        if x11>x22 and x11>x33:
            x2=x11
            y2=y11
            if x22>x33:
                x3=x22
                y3=y22
                x4=x33
                y4=y33
            else:
                x3=x33
                y3=y33
                x4=x22
                y4=y22
        elif x22>x11 and x22>x33:
            x2=x22
            y2=y22
            if x11>x33:
                x3=x11
                y3=y11
                x4=x33
                y4=y33
            else:
                x3=x33
                y3=y33
                x4=x11
                y4=y11
        elif x33>x11 and x33>x22:
            x2=x33
            y2=y33
            if x11>x22:
                x3=x11
                y3=y11
                x4=x22
                y4=y22
            else:
                x3=x22
                y3=y22
                x4=x11
                y4=y11
    l1=(x2-x1)*(x2-x1)+(y2-y1)*(y2-y1)
    l2=(x2-x3)*(x2-x3)+(y2-y3)*(y2-y3)
    l3=(x4-x3)*(x4-x3)+(y4-y3)*(y4-y3)
    l4=(x4-x1)*(x4-x1)+(y4-y1)*(y4-y1)


#在给定的色块列表中寻找1个最大的色块，ID存在max_ID中，便于调用
def find_max(blobs):
    max_size=0
    for blob in blobs:
        if blob[2]*blob[3] > max_size:
            max_blob=blob
            max_size = blob[2]*blob[3]
    return max_blob



def sending_data(x,y,m,n):
    FH = bytearray([0x2C,0x12,int(x),int(y),int(m),int(n),0x5B])
    uart.write(FH);

def Err_send(err_x,err_y):
    if err_x<-3:
        uart.write("1")  #收到1 down舵机向右转向
    elif err_x>3:
        uart.write("2")  #收到2 down舵机向左转向
    if err_y<-3:
        uart.write("3")  #收到3 up舵机向下转向
    elif err_y>3:
        uart.write("4")  #收到4 up舵机向上转向

def X_send(err_x):
    if err_x<-3:
        uart.write("1")  #收到1 down舵机向右转向
    elif err_x>3:
        uart.write("2")  #收到2 down舵机向左转向

def Y_send(err_y):
    if err_y<-3:
        uart.write("3")  #收到3 up舵机向下转向
    elif err_y>3:
        uart.write("4")  #收到4 up舵机向上转向



nn=0
while(True):
    clock.tick()

    if uart.any():
        data=uart.readline().decode().strip()  #转化为字符串接收
    img = sensor.snapshot()  #截取摄像头的一个图像
    blob=img.find_blobs([red_threshold],  x_stride=10, y_stride=5,pixels_threshold=10, area_threshold=10, merge=True)   #模板匹配函数
    if data=='1':
        img = sensor.snapshot()  #截取摄像头的一个图像
        blob=img.find_blobs([red_threshold],  x_stride=10, y_stride=5,pixels_threshold=10, area_threshold=10, merge=True)   #模板匹配函数
    elif data=='2' or data=='3':
        img = sensor.snapshot().lens_corr(strength = 1.8, zoom = 1.0)

    elif data=='4' and flag44<=2:
        flag44=flag44+1
        img = sensor.snapshot().lens_corr(strength = 1.8, zoom = 1.0)
        for r in img.find_rects(threshold = 10000,roi=ROI4):
            # 判断矩形边长是否符合要求
            if r.w() > 20 and r.h() > 20:
                # 在屏幕上框出矩形
                #img.draw_rectangle(r.rect(), color = (255, 0, 0), scale = 4)
                # 获取矩形角点位置
                corner = r.corners()
                # 在屏幕上圈出矩形角点
                img.draw_circle(corner[0][0], corner[0][1], 5, color = (0, 0, 255), thickness = 2, fill = False)
                img.draw_circle(corner[1][0], corner[1][1], 5, color = (0, 0, 255), thickness = 2, fill = False)
                img.draw_circle(corner[2][0], corner[2][1], 5, color = (0, 0, 255), thickness = 2, fill = False)
                img.draw_circle(corner[3][0], corner[3][1], 5, color = (0, 0, 255), thickness = 2, fill = False)

            # 打印四个角点坐标, 角点1的数组是corner[0], 坐标就是(corner[0][0],corner[0][1])
            # 角点检测输出的角点排序每次不一定一致，矩形左上的角点有可能是corner0,1,2,3其中一个
            corner1_str = f"corner1 = ({corner[0][0]},{corner[0][1]})"
            corner2_str = f"corner2 = ({corner[1][0]},{corner[1][1]})"
            corner3_str = f"corner3 = ({corner[2][0]},{corner[2][1]})"
            corner4_str = f"corner4 = ({corner[3][0]},{corner[3][1]})"
            PaiXun(corner[0][0],corner[1][0],corner[2][0],corner[3][0],corner[0][1],corner[1][1],corner[2][1],corner[3][1])


            #print(corner1_str + "\n" + corner2_str + "\n" + corner3_str + "\n" + corner4_str)



    if blob:
        max_ID=[-1]
        max_ID=find_max(blob)  #找最大色块
        img.draw_rectangle(max_ID.rect())
        img.draw_cross(max_ID.cx(),max_ID.cy())


        #print('x='+str(blob.cx())+'  y='+str(blob.cy()))
        x=max_ID.cx()
        y=max_ID.cy()
        w=max_ID.w()   #5cm -- 85
        #print(max_ID.area())
        #print(w)
        #print('x='+str(max_ID.cx())+'  y='+str(max_ID.cy()))

    if data=='1':
        err_x=x-287
        err_y=y-232
        if err_x<-3:
            uart.write("1")  #收到1 down舵机向右转向
        elif err_x>3:
            uart.write("2")  #收到2 down舵机向左转向
        if err_y<-3:
            uart.write("3")  #收到3 up舵机向下转向
        elif err_y>3:
            uart.write("4")  #收到4 up舵机向上转向
        if err_x<10 and err_x>-10 and err_y<3 and err_y>-3:
            uart.write("S")


    elif data=='2':
        if flag2==0:
            err_x=x-154
            err_y=y-375
            Err_send(err_x,err_y)
            if err_x<15 and err_x>-15 and err_y<0 and err_y>-10:
                uart.write("5")
                flag2=1

    elif data=='3':
        if flag3==0:
            err_x=x-171
            err_y=y-189
            Err_send(err_x,err_y)
            if err_x<5 and err_x>-5 and err_y<50 and err_y>-50:
                uart.write("5")
                flag3=1

    elif data=='4':
        m=9
        if flag4==0:
            err_x=x-x1
            err_y=y-y1
            if err_x<m and err_x>-m and err_y<m and err_y>-m:
                flag4=1
        if flag4==1:
            err_x=x-x2
            err_y=y-y2
            if err_x<m and err_x>-m and err_y<m and err_y>-m:
                flag4=2
        if flag4==2:
            err_x=x-x3
            err_y=y-y3
            if err_x<m and err_x>-m and err_y<m and err_y>-m:
                flag4=3
        if flag4==3:
            err_x=x-x4
            err_y=y-y4
            if err_x<m and err_x>-m and err_y<m and err_y>-m:
                flag4=4
        if flag4==4:
            err_x=x-x1
            err_y=y-y1
            if err_x<m and err_x>-m and err_y<m and err_y>-m:
                flag4=5
        send_flag=send_flag+1
        if send_flag%2==1:
            X_send(err_x)
            time.sleep_ms(10)
        else:
            Y_send(err_y)
            time.sleep_ms(10)
