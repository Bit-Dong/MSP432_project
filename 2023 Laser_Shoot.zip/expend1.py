import sensor, image, time
import  math, pyb, json ,sensor
from machine import Pin

from image import SEARCH_EX, SEARCH_DS
from pid import PID
from pyb import Servo
from pyb import UART,LED
pan_servo=Servo(1)#水平方向的舵机
tilt_servo=Servo(2)#垂直方向的舵机

pan_servo.calibration(500,2500,500)
tilt_servo.calibration(500,2500,500)

red_threshold  =  (85, 100, -3, 20, -2, 17)    #黄色色块
uart = UART(3, 115200)

pan_pid = PID(p=0.07, i=0, imax=90) #脱机运行或者禁用图像传输，使用这个PID
tilt_pid = PID(p=0.04, i=0, imax=90) #脱机运行或者禁用图像传输，使用这个PID

sensor.reset() # Initialize the camera sensor.
sensor.set_pixformat(sensor.RGB565) # use RGB565.
sensor.set_framesize(sensor.QVGA) # use QQVGA for speed.
sensor.skip_frames(10) # Let new settings take affect.
sensor.set_auto_whitebal(False) # turn this off.
sensor.set_vflip(1)
clock = time.clock() # Tracks FPS.

def find_max(blobs):
    max_size=[0,0]
    max_ID=[-1,-1]
    for i in range(len(blobs)):
        if blobs[i].pixels()>max_size[0]:
            max_ID[1]=max_ID[0]
            max_size[1]=max_size[0]
            max_ID[0]=i
            max_size[0]=blobs[i].pixels()
        elif blobs[i].pixels()>max_size[1]:
            max_ID[1]=i
            max_size[1]=blobs[i].pixels()
    return max_ID


out=2
flag=0
pan_servo.angle(pan_servo.angle()-10)
time.sleep_ms(300)
while(True):
    clock.tick() # Track elapsed milliseconds between snapshots().
    img = sensor.snapshot() # Take a picture and return the image.

    blobs = img.find_blobs([red_threshold])
    if blobs:
        max_ID=[-1,-1]
        max_ID=find_max(blobs)  #找最大两色块
        pan_error = blobs[max_ID[1]].cx()-img.width()/2
        tilt_error = blobs[max_ID[1]].cy()-img.height()/2



        if flag==0:
            print(flag)
            if abs(blobs[max_ID[0]].cx()-blobs[max_ID[1]].cx())<30:
                flag=1
            else:
                pan_servo.angle(pan_servo.angle()+out)

        if flag==1:
            print(flag)
            if abs(blobs[max_ID[0]].cy()-blobs[max_ID[1]].cy())<=25:
                while(1):
                    uart.write("f")
                    flag=0
            else:
                tilt_servo.angle(tilt_servo.angle()+2)




