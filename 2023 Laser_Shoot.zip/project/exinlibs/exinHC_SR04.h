#ifndef  _exinHC_SR04_h
#define  _exinHC_SR04_h

#ifdef __cplusplus
extern "C"
{
#endif

#define TRIG_PORT GPIO_PORT_P1
#define TRIG_PIN GPIO_PIN6    //P1.6
#define ECHO_PORT GPIO_PORT_P1
#define ECHO_PIN GPIO_PIN7    //P1.7

extern void HC_SR04_init(void);
extern float HC_SR04_dis(void);
#ifdef __cplusplus
}
#endif

#endif // __DRIVERLIB_GPIO_H__
