#ifndef _exinIIC_H_
#define _exinIIC_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include "dat.h"
#include "motor.h"


#define IIC_SCL_PORT         GPIO_PORT_P6
#define IIC_SCL_PIN          GPIO_PIN4  //P6.4

#define IIC_SDA_PORT         GPIO_PORT_P6
#define IIC_SDA_PIN          GPIO_PIN5  //P6.5

#define IIC_SCL_OUT           gpio_init(IIC_SCL_PORT,IIC_SCL_PIN,0,1)
#define IIC_SCL_IN            gpio_init(IIC_SCL_PORT,IIC_SCL_PIN,1,1)
#define IIC_SDA_OUT           gpio_init(IIC_SDA_PORT,IIC_SDA_PIN,0,0)
#define IIC_SDA_IN            gpio_init(IIC_SDA_PORT,IIC_SDA_PIN,1,0)

#define IIC_SCL_HIGH          gpio_set(IIC_SCL_PORT,IIC_SCL_PIN,1)
#define IIC_SCL_LOW           gpio_set(IIC_SCL_PORT,IIC_SCL_PIN,0)

#define IIC_SDA_HIGH          gpio_set(IIC_SDA_PORT,IIC_SDA_PIN,1)
#define IIC_SDA_LOW           gpio_set(IIC_SDA_PORT,IIC_SDA_PIN,0)

#define IIC_SDA_READ          gpio_get(IIC_SDA_PORT,IIC_SDA_PIN)
#define IIC_SCL_READ          gpio_get(IIC_SCL_PORT,IIC_SCL_PIN)

#define IIC_delay            delay_us(2)

extern uint8 IIC_DATA;

extern void IIC_init(void);
extern void IIC_start(void);
extern void IIC_stop(void);
extern void IIC_ACK(void);
extern void IIC_NACK(void);
extern unsigned char Check_ACK(void);
extern void IIC_Send_Byte(uint8 Data);
extern unsigned char IIC_Read_Byte(uint8 ack);
extern void IIC_reset(void);

#ifdef __cplusplus
}
#endif

#endif

