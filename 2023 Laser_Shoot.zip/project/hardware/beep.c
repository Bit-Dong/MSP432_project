#include "beep.h"
#include "motor.h"





void Beep_Init(void)
{
	gpio_init(GPIO_PORT_P10,GPIO_PIN1,0,0); 
}

void Beep_OFF(void)
{
	gpio_set_Low(GPIO_PORT_P10,GPIO_PIN1);
}

void Beep_ON(void)
{
	gpio_set_High(GPIO_PORT_P10,GPIO_PIN1);
}
