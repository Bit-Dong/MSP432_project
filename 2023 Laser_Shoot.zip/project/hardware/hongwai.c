#include "hongwai.h"
#include "motor.h"


void HongWai_Init(void)
{
	gpio_init(GPIO_PORT_P10,GPIO_PIN3,1,1);   //��ײ����ʼ��  Ĭ�ϸߵ�ƽ
	gpio_init(GPIO_PORT_P10,GPIO_PIN5,1,0);	  //����Թܳ�ʼ��  Ĭ�ϵ͵�ƽ
	
	gpio_init(GPIO_PORT_P8,GPIO_PIN6,1,0);   //�Ҷ�ѭ����ʼ����Ĭ��Ϊ�͵�ƽ
	gpio_init(GPIO_PORT_P8,GPIO_PIN7,1,0);
	gpio_init(GPIO_PORT_P9,GPIO_PIN1,1,0);
	gpio_init(GPIO_PORT_P8,GPIO_PIN3,1,0);
	gpio_init(GPIO_PORT_P5,GPIO_PIN3,1,0);
	gpio_init(GPIO_PORT_P9,GPIO_PIN3,1,0);
	gpio_init(GPIO_PORT_P6,GPIO_PIN3,1,0);	
	gpio_init(GPIO_PORT_P7,GPIO_PIN2,1,0);
	gpio_init(GPIO_PORT_P7,GPIO_PIN0,1,0);
	gpio_init(GPIO_PORT_P9,GPIO_PIN5,1,0);
//	gpio_init(GPIO_PORT_P9,GPIO_PIN7,1,0);
	gpio_init(GPIO_PORT_P7,GPIO_PIN5,1,0);	
	gpio_init(GPIO_PORT_P7,GPIO_PIN7,1,0);
	
	
}

