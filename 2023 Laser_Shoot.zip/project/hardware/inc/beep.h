#ifndef __BEEP_H
#define __BEEP_H
#include <ti/devices/msp432p4xx/driverlib/driverlib.h>

void Beep_Init(void);
void Beep_OFF(void);
void Beep_ON(void);

#endif
