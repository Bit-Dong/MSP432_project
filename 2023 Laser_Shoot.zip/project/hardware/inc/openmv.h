#ifndef __OPENMV_H
#define __OPENMV_H
#include <ti/devices/msp432p4xx/driverlib/driverlib.h>
#include <stdio.h> //1.61328125kb

void OpenMV2_Init(void);

#endif
