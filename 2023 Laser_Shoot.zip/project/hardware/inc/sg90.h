#ifndef __SG90_H
#define __SG90_H
#include <ti/devices/msp432p4xx/driverlib/driverlib.h>
#include "timA.h"
#include "delay.h"


void Steer_Down_angle(double a);
void Steer_Up_angle(double a);
void Steer_Down_Cal(void);
void Steer_Up_Cal(void);
void text2(void);

#endif
