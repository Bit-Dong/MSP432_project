#include "sg90.h"
#include "delay.h"
/*
                20msΪ��
        0.5ms ------------ 0�ȣ�
        1.0ms ------------ 45�ȣ�
        1.5ms ------------ 90�ȣ�
        2.0ms ------------ 135�ȣ�
        2.5ms ------------ 180�ȣ�
*/

void Steer_Up_angle(double a)
{
    int pwm=500+2000/180*a;
    MAP_Timer_A_setCompareValue(TIMER_A3_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_3, pwm);
} 

void Steer_Down_angle(double a)
{
    int pwm=500+2000/180*a;
    MAP_Timer_A_setCompareValue(TIMER_A3_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, pwm);
}


void Steer_Up_Cal(void)
{
    int i=0,j=0;
    for(i=0;i<=180;i++)
    {
		delay_ms(5);
        Steer_Up_angle(i);
    }
    for(j=180;j>=0;j--)
    {
		delay_ms(5);
        Steer_Up_angle(j);
    }
}

void Steer_Down_Cal(void)
{
    int i=0,j=0;
    for(i=0;i<=180;i++)
    {
		delay_ms(5);
        Steer_Down_angle(i);
    }
    for(j=180;j>=0;j--)
    {
		delay_ms(5);
        Steer_Down_angle(j);
    }
}

void text2()
{
    int i;
    int j;
    Steer_Down_angle(110);
    Steer_Up_angle(120);
    for(i=110;i>=70;i--)
    {
        delay_ms(100);
        Steer_Down_angle(i);
    }
    for(j=120;j>=90;j--)
    {
        delay_ms(100);
        Steer_Up_angle(j);
    }
    for(i=70;i<=110;i++)
    {
        delay_ms(100);
        Steer_Down_angle(i);
    }
    for(j=90;j<=120;j++)
    {
        delay_ms(100);
        Steer_Up_angle(j);
    }
    
//    
//    Steer_Down_angle(90);
//    Steer_Up_angle(105);
//    delay_ms(600);
}

