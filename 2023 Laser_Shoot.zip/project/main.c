#include "sysinit.h"
#include "usart.h"
#include "timA.h"
#include "usart.h"
#include "led.h"
#include "delay.h"
#include "key.h"
#include "sg90.h"
#include "openmv.h"
#include "beep.h"
#include "pwm.h"
#include "stdio.h"
#include "math.h"
#include "stdlib.h"
#include "PID.h"

/*                           MSP432P401R
 *
 *	Beep：		 P10.1  															-----  高电平触发
 *  RGB灯：		 P3.5(红)	       P3.6(绿)         P3.7(蓝)						-----  高电平触发
 *  Steer:		 P8.2(下)			   P9.2(上)										-----  TA3 CH2~CH3    若使用OpenMV驱动舵机，则P8.2改为OpenMV引脚的P7，P9.2改接P8【需公地】
 *  OpenMV：	 P3.2(RX)			   P3.3(TX)										-----  Uart2
 *  
 */
void basic_one(void);
void basic_two(void);
void basic_three(void);
void basic_four(void);

#define CLKDIV2 48   //时钟源分频   Steer 
#define CCR2 20000   // 比较值    Steer

int x1,x2,y1,y2;
uint8_t key;  			//按键检测
int steer_x=115,steer_y=115,steer;			//舵机转向角度
int x_flag=0,y_flag=0;
char openmv_rx2;		//OpenMV1 接收串口2字符
int n=0;
int one_flag=0;
int mode=0;
double Timer=0;  		//运行时间


int main(void)
{
    SysInit(); 							//时钟初始化
	LED_Init();							//LED初始化
	uart_init(115200);
    delay_init(); 						//延时初始化
	KEY_Init();							//按键初始化
	OpenMV2_Init();						//OpenMV2初始化      串口A2
	TimA3_Steer_Init(CCR2,CLKDIV2);		//定时器A3初始化    舵机脉冲调制
	Steer_Up_angle(106);                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
	Steer_Down_angle(90);	
	Beep_Init();
	
    while (1)
    {			
		
		key=KEY_Scan(0);
		if(key==KEY1_PRES)
		{
			delay_ms(100);
			one_flag++;
		}
		if(key==KEY2_PRES)
		{
			mode=1;
			if(one_flag==1)
			{
				
				
				
			}
			else if(one_flag==2)     
			{
				
				

			}
			else if(one_flag==3)     
			{
				
				
				
			}
			else if(one_flag==4)     
			{
				UART_transmitData(EUSCI_A2_BASE, '4'); //发送数据
				delay_ms(500);
				steer_x=1500; 
				steer_y=1766;
				delay_ms(500);					
			}
		}
		if(one_flag==1&&mode==1)
		{			
			basic_one();
		}
		else if(one_flag==2&&mode==1)
		{			
			basic_two();
		}
		else if(one_flag==3&&mode==1)
		{			
			basic_three();
			
		}
		else if(one_flag==4&&mode==1)
		{			
			basic_four();		
				
		}
	
	}
}



//OpenMV
void EUSCIA2_IRQHandler(void)
{
    uint32_t status = UART_getEnabledInterruptStatus(EUSCI_A2_BASE);   //获取中断状态
    if(status & EUSCI_A_UART_RECEIVE_INTERRUPT_FLAG) 		//接收中断
    {
		openmv_rx2=MAP_UART_receiveData(EUSCI_A2_BASE);//接收数据
		if(openmv_rx2=='f')
		{
			delay_ms(2000);
			while(1)
			{
				LED_R_On();
				Beep_ON();
				delay_ms(500);
				Beep_OFF();
				LED_R_Off();
				delay_ms(500);
			}

		}
//		UART_transmitData(EUSCI_A2_BASE, 'z'); //发送数据
    }
	//UART_disableInterrupt(EUSCI_A2_BASE, EUSCI_A_UART_RECEIVE_INTERRUPT);   //关闭接收中断
//	UART_enableInterrupt(EUSCI_A2_BASE, EUSCI_A_UART_RECEIVE_INTERRUPT);    //开启接收中断 
//	
}

void basic_one(void)
{
	Steer_Up_angle(109);                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
	Steer_Down_angle(76);
}

void basic_two(void)
{
		while(1)
		{
			int i;
			for(i=96;i<123;i++)
			{
				if(i==105) Steer_Down_angle(91);
				Steer_Up_angle(i);
				delay_ms(80);
			}
			for(i=88;i>=63;i--)
			{
				if(i==87) Steer_Up_angle(123);
				Steer_Down_angle(i);
				delay_ms(80);
			}
			for(i=122;i>=95;i--)
			{
				if(i==115) Steer_Down_angle(62);
				Steer_Up_angle(i);
				delay_ms(80);
			}
			for(i=63;i<=90;i++)
			{
				Steer_Down_angle(i);
				delay_ms(80);
			}
		}
}

void basic_three(void)
{
	Steer_Down_angle(92);
		while(1)
		{
			int i;
			for(i=113;i<=123;i++)
			{
				Steer_Up_angle(i);
				delay_ms(200);
			}
			for(i=88;i>=76;i--)
			{
				Steer_Down_angle(i);
				delay_ms(200);
			}
			for(i=122;i>=112;i--)
			{
				Steer_Up_angle(i);
				delay_ms(200);
			}
			for(i=76;i<=92;i++)
			{
				Steer_Down_angle(i);
				delay_ms(200);
			}
		}
}





void basic_four(void)
{
	if(openmv_rx2=='1')
	{		
		steer_x--;
		MAP_Timer_A_setCompareValue(TIMER_A3_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, steer_x);
	}
	else if(openmv_rx2=='2')
	{
		steer_x++;
		MAP_Timer_A_setCompareValue(TIMER_A3_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, steer_x);
	}
	else if(openmv_rx2=='3')
	{
		steer_y--;
		MAP_Timer_A_setCompareValue(TIMER_A3_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_3, steer_y);
	}
	else if(openmv_rx2=='4')
	{
		steer_y++;	
		MAP_Timer_A_setCompareValue(TIMER_A3_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_3, steer_y);
	}	
	delay_ms(10);
	
}
