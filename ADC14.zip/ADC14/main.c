#include "sysinit.h"
#include "usart.h"
#include "delay.h"
#include "adc.h"

/************************
 *
 * 最大采集电压 3.3V
 * 
 * 实验现象：
 * 串口打印ADC采集电压
 *
 * ADC采集引脚：
 * 单路 为 P5.5
 * 双路 为 P5.5 P5.4
 * 三路 为 P5.5 P5.4 P5.3
 * 可在adc.c中配置采集次数与采集路数
 *
 ************************/

int main(void)
{
    SysInit();         
    uart_init(115200);
    delay_init();     
    ADC_Config();     
	
    while (1)
    {
    }
}
