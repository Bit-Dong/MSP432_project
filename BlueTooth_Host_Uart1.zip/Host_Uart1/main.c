/******************************************************************************
// MSP432P401R
// 7 串口配置
// Bilibili：m-RNA
// E-mail:m-RNA@qq.com
// 创建日期:2021/8/25
*******************************************************************************/

/*
 * 2021/10/15 更新
 * 
 * 此版本支持 标准C库
 * 终于可以不使用微库啦
 *
 * 使用标准C库时，将无法使用scanf；
 * 如果需要使用scanf时，请使用微库 MicroLIB。
 * 
 */

#include "sysinit.h"
#include "usart.h"
#include "baudrate_calculate.h"
#include "key.h"
#include "led.h"

char c=0;
uint8_t key;


int main(void)
{
    /* Halting WDT  */
    MAP_WDT_A_holdTimer();

    //0.配置时钟
    SysInit();
	
    LED_Init();
	KEY_Init();
	
	UARTA1_Init();

	

    while(1)
    {
		key = KEY_Scan(0);
        if (key == KEY1_PRES)
		{
			UART_enableInterrupt(EUSCI_A1_BASE, EUSCI_A_UART_RECEIVE_INTERRUPT);    //开启接收中断 
            UART_transmitData(EUSCI_A1_BASE, 'b'); //发送数据
		}
        else if (key == KEY2_PRES)
            UART_disableInterrupt(EUSCI_A1_BASE, EUSCI_A_UART_RECEIVE_INTERRUPT);   //关闭接收中断
		
		if(c=='1') 
		{
			c='0';
			int i,j;
			LED_Y_On();
			for (i = 0; i < 500000; i++);
			LED_P_On();
			for (j = 0; j < 500000; j++);
		}
			
		else if(c=='2') 
		{
			c='0';
			int i,j;
			LED_Y_On();
			for (i = 0; i < 500000; i++);
			LED_P_On();
			for (j = 0; j < 500000; j++);
		}		
    }
}


//8.编写UART ISR
void EUSCIA1_IRQHandler(void)
{
    uint32_t status = UART_getEnabledInterruptStatus(EUSCI_A1_BASE);

    if(status & EUSCI_A_UART_RECEIVE_INTERRUPT_FLAG) //接收中断
    {
		c=MAP_UART_receiveData(EUSCI_A1_BASE);
        
    }

}
