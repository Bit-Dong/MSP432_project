#ifndef __BLURTOOTH_H
#define __BLURTOOTH_H
#include <ti/devices/msp432p4xx/driverlib/driverlib.h>
#include <stdio.h> //1.61328125kb

void BlueTooth_Init(void);

#endif
