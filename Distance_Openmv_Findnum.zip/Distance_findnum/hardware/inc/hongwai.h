#ifndef __HONGWAI_H
#define __HONGWAI_H
#include <ti/devices/msp432p4xx/driverlib/driverlib.h>

void HongWai_Init(void);

#endif
