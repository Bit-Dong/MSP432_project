import time, sensor, image, ustruct
from image import SEARCH_EX, SEARCH_DS
from pyb import UART,LED

one=LED(1)
clock = time.clock()
# Reset sensor
sensor.reset()

# Set sensor settings
sensor.set_contrast(1)    #设置对比度
sensor.set_gainceiling(16)     #设定增益曲线
# Max resolution for template matching with SEARCH_EX is QQVGA
sensor.set_framesize(sensor.QQVGA)
# You can set windowing to reduce the search image.
#sensor.set_windowing(((320-40), (240-30), 80, 60))
sensor.set_pixformat(sensor.GRAYSCALE)

uart = UART(3, 115200)

templates3=["/test_num/32.pgm","/test_num/33.pgm","/test_num/34.pgm","/test_num/35.pgm","/test_num/36.pgm","/test_num/37.pgm","/test_num/38.pgm","/test_num/39.pgm"]
templates4=["/test_num/42.pgm","/test_num/43.pgm","/test_num/44.pgm","/test_num/45.pgm","/test_num/46.pgm","/test_num/47.pgm","/test_num/48.pgm","/test_num/49.pgm"]
templates5=["/test_num/52.pgm","/test_num/53.pgm","/test_num/54.pgm","/test_num/55.pgm","/test_num/56.pgm","/test_num/57.pgm","/test_num/58.pgm","/test_num/59.pgm"]
templates6=["/test_num/62.pgm","/test_num/63.pgm","/test_num/64.pgm","/test_num/65.pgm","/test_num/66.pgm","/test_num/67.pgm","/test_num/68.pgm","/test_num/69.pgm"]
templates7=["/test_num/72.pgm","/test_num/73.pgm","/test_num/74.pgm","/test_num/75.pgm","/test_num/76.pgm","/test_num/77.pgm","/test_num/78.pgm","/test_num/79.pgm"]
templates8=["/test_num/82.pgm","/test_num/83.pgm","/test_num/84.pgm","/test_num/85.pgm","/test_num/86.pgm","/test_num/87.pgm","/test_num/88.pgm","/test_num/89.pgm"]

temp=["/test_num/3.pgm","/test_num/4.pgm", "/test_num/5.pgm", "/test_num/6.pgm", "/test_num/7.pgm", "/test_num/8.pgm"]

temp3 = [0,0,0,0,0,0,0,0]
temp4 = [0,0,0,0,0,0,0,0]
temp5 = [0,0,0,0,0,0,0,0]
temp6 = [0,0,0,0,0,0,0,0]
temp7 = [0,0,0,0,0,0,0,0]
temp8 = [0,0,0,0,0,0,0,0]
imgarray=[0,0,0,0,0,0]  #初始八个数据模板
first=0                     #初识别数字
second=0
data=0
global num
x=0
y=0
second_flag=0
roi=(10, 0, 200, 200)

def loadimg():
    i=0
    for t in temp:
        imgarray[i]=image.Image(str(t))
        i+=1
    return imgarray

def load3():
    i=0
    for t in templates3:
        temp3[i]=image.Image(str(t))
        i+=1
    return temp3

def load4():
    i=0
    for t in templates4:
        temp4[i]=image.Image(str(t))
        i+=1
    return temp4

def load5():
    i=0
    for t in templates5:
        temp5[i]=image.Image(str(t))
        i+=1
    return temp5

def load6():
    i=0
    for t in templates6:
        temp6[i]=image.Image(str(t))
        i+=1
    return temp6

def load7():
    i=0
    for t in templates7:
        temp7[i]=image.Image(str(t))
        i+=1
    return temp7

def load8():
    i=0
    for t in templates8:
        temp8[i]=image.Image(str(t))
        i+=1
    return temp8




def get_first(img):
    global imgarray
    i=2
    for t in imgarray:
        r = img.find_template(t, 0.70, step=4, search=SEARCH_EX, roi=roi) #, roi=(10, 0, 60, 60))
        i+=1
        if r:
            return i
    return 0

def led_show(num):
    if num is not 0:
        for i in range (num):
            one.on()
            print(num) #使用时删除 给自己看的
            time.sleep_ms(300)
            one.off()
            time.sleep_ms(300)

def send_num(num):
    if num==3:
        uart.write("3")
    elif num==4:
        uart.write("4")
    elif num==5:
        uart.write("5")
    elif num==6:
        uart.write("6")
    elif num==7:
        uart.write("7")
    elif num==8:
        uart.write("8")

def get_second(img):
    global temp3
    global temp4
    global temp5
    global temp6
    global temp7
    global temp8
    global x
    global y
    i=2

    for t in temp3:
        r = img.find_template(t, 0.70, step=4, search=SEARCH_EX) #, roi=(10, 0, 60, 60))
        i+=1
        if r:
            img.draw_rectangle(r)
            x = r[0] + roi[0]  # 矩形相对于整个图像的 x 坐标
            y = r[1] + roi[1]  # 矩形相对于整个图像的 y 坐标
            print('x='+str(x)+'  y='+str(y))
            return 3
    for t in temp4:
        r = img.find_template(t, 0.70, step=4, search=SEARCH_EX) #, roi=(10, 0, 60, 60))
        i+=1
        if r:
            img.draw_rectangle(r)
            x = r[0] + roi[0]  # 矩形相对于整个图像的 x 坐标
            y = r[1] + roi[1]  # 矩形相对于整个图像的 y 坐标
            print('x='+str(x)+'  y='+str(y))
            return 4
    for t in temp5:
        r = img.find_template(t, 0.70, step=4, search=SEARCH_EX) #, roi=(10, 0, 60, 60))
        i+=1
        if r:
            img.draw_rectangle(r)
            x = r[0] + roi[0]  # 矩形相对于整个图像的 x 坐标
            y = r[1] + roi[1]  # 矩形相对于整个图像的 y 坐标
            print('x='+str(x)+'  y='+str(y))
            return 5
    for t in temp6:
        r = img.find_template(t, 0.70, step=4, search=SEARCH_EX) #, roi=(10, 0, 60, 60))
        i+=1
        if r:
            img.draw_rectangle(r)
            x = r[0] + roi[0]  # 矩形相对于整个图像的 x 坐标
            y = r[1] + roi[1]  # 矩形相对于整个图像的 y 坐标
            print('x='+str(x)+'  y='+str(y))
            return 6
    for t in temp7:
        r = img.find_template(t, 0.70, step=4, search=SEARCH_EX) #, roi=(10, 0, 60, 60))
        i+=1
        if r:
            img.draw_rectangle(r)
            x = r[0] + roi[0]  # 矩形相对于整个图像的 x 坐标
            y = r[1] + roi[1]  # 矩形相对于整个图像的 y 坐标
            print('x='+str(x)+'  y='+str(y))
            return 7
    for t in temp8:
        r = img.find_template(t, 0.70, step=4, search=SEARCH_EX) #, roi=(10, 0, 60, 60))
        i+=1
        if r:
            img.draw_rectangle(r)
            x = r[0] + roi[0]  # 矩形相对于整个图像的 x 坐标
            y = r[1] + roi[1]  # 矩形相对于整个图像的 y 坐标
            print('x='+str(x)+'  y='+str(y))
            return 8
    return 0

imgarray=loadimg()                              #加载初始八张图

temp3=load3()
temp4=load4()
temp5=load5()
temp6=load6()
temp7=load7()
temp8=load8()
while (True):
    clock.tick()
    global num

    img = sensor.snapshot()
    if first==0:                                #获取初始图片标志位
        first=get_first(img)                    #first用于判断当前是那张图片
        num=first
        send_num(num)
        led_show(num)
    if second==0:
        if uart.any():
            data=uart.readline().decode().strip()  #转化为字符串接收
            if data=='1':
                print('ok1')
                second=1
                data='0'
                while (True):
                    img = sensor.snapshot()
                    second=get_second(img)
                    print(second)
                    if second==num:
                        if(x>=50):
                            print('R')
                            uart.write(bytes([0x0b]))
                            led_show(second)
                            break
                        else:
                            print('L')
                            uart.write(bytes([0x0a]))
                            led_show(second)
                            break




