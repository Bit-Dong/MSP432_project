#include "exit.h"
#include "led.h"
#include "usart.h"

int num=0,num1=0;

void Exit_Init(void) 
{
	//IO��ʼ��
	GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P5, GPIO_PIN5);
	GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P6, GPIO_PIN5);
	
	//2.����жϱ�־λ
	GPIO_clearInterruptFlag(GPIO_PORT_P5, GPIO_PIN5);
	GPIO_clearInterruptFlag(GPIO_PORT_P6, GPIO_PIN5);
	
	//3.���ô�����ʽ
	GPIO_interruptEdgeSelect(GPIO_PORT_P5, GPIO_PIN5,GPIO_HIGH_TO_LOW_TRANSITION);
	GPIO_interruptEdgeSelect(GPIO_PORT_P6, GPIO_PIN5,GPIO_LOW_TO_HIGH_TRANSITION);
	
	//4.�����ⲿ�ж�
	GPIO_enableInterrupt(GPIO_PORT_P5, GPIO_PIN5);
	GPIO_enableInterrupt(GPIO_PORT_P6, GPIO_PIN5);
	
	//5.�����˿��ж�
	Interrupt_enableInterrupt(INT_PORT5);
	Interrupt_enableInterrupt(INT_PORT6);
	
	//6.�������ж�
	Interrupt_enableMaster();
}


void PORT5_IRQHandler(void)
{
	uint16_t status;
	status = GPIO_getEnabledInterruptStatus(GPIO_PORT_P5);
	GPIO_clearInterruptFlag(GPIO_PORT_P5,status);
	
	if(BITBAND_PERI(P5IN, 5)==0)
	{		
		num++;
		printf("\r\n num=%d\r\n", num);
	}

}

void PORT6_IRQHandler(void)
{
	uint16_t status;
	status = GPIO_getEnabledInterruptStatus(GPIO_PORT_P6);
	GPIO_clearInterruptFlag(GPIO_PORT_P6,status);
	
	if(BITBAND_PERI(P6IN, 5)==1)
	{		
		num1++;
		printf("\r\n num1=%d\r\n", num1);
	}
}







