#include "sysinit.h"
#include "usart.h"
#include "key4x4.h"
#include "exit.h"

int main(void)
{
    SysInit();         
    uart_init(115200);     
	Exit_Init();
	
    while (1)
    {
            
    }
}
