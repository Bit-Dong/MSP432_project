#include "sysinit.h"
#include "usart.h"
#include "baudrate_calculate.h"
#include "key.h"
#include "led.h"
#include "string.h"	 

u8 sum=0,i=0;
sensor GY56;

int main(void)
{
    /* Halting WDT  */
    MAP_WDT_A_holdTimer();

    //0.配置时钟
    SysInit();
	
    LED_Init();
	KEY_Init();
	uart_init(115200);
	UARTA2_Init();

	send_com(0x76,1);//发送连续输出指令

    while(1)
    {
		if(Receive_ok)//串口接收完毕
		{
			for(sum=0,i=0;i<(re_Buf_Data[3]+4);i++)
			sum+=re_Buf_Data[i];
			if(sum==re_Buf_Data[i])//校验和判断
			{
				GY56.distance=re_Buf_Data[4]<<8|re_Buf_Data[5];
				GY56.mode=re_Buf_Data[6];
				GY56.temp=re_Buf_Data[7];		
				printf("%d\r\n",GY56.distance);
			}
			Receive_ok=0;//处理数据完毕标志
		}
		
    }
}





