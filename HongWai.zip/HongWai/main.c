#include "sysinit.h"
#include "usart.h"
#include "timA.h"
#include "usart.h"
#include "led.h"
#include "motor.h"

#define CLKDIV 64   //时钟源分频
#define CCR0 1000  // 比较值0

/*
 * 定时器中断周期：
 *
 * T_timer_a = CLKDIV * (CCR0 + 1) / f_clk 
 *           = 64 * 37500 / 48000000 
 *           = 0.05s = 20Hz
 */
 
int main(void)
{
    SysInit();  			    
	LED_Init();	
	
	gpio_init(GPIO_PORT_P3,GPIO_PIN6,1,1);   //初始化P36、P37为输入模式，且默认为高电平
	gpio_init(GPIO_PORT_P3,GPIO_PIN7,1,1);
	
    while (1)
    {
		int i=gpio_get(GPIO_PORT_P3,GPIO_PIN6);  //获取电平状态
		int j=gpio_get(GPIO_PORT_P3,GPIO_PIN7);
		if(i==0&&j==1)   //踩到黑线为0
		{
			LED_W_On();
		}
		else if(i==1&&j==0)
		{
			LED_Y_On();
		}
		else if(i==0&&j==0)
		{
			LED_P_On();
		}
		else
		{
			LED_R_Off();
			LED_G_Off();
			LED_B_Off();
		}
    }
}


