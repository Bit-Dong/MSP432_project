#include "sysinit.h"
#include "usart.h"
#include "key4x4.h"

int main(void)
{
    uint8_t key_value;

    SysInit();         
    uart_init(115200); 
    KEY4x4_Init();     

	
    while (1)
    {
        key_value = KEY4x4_Scan(0);
        if (key_value)
            printf("%d", key_value);
    }
}
