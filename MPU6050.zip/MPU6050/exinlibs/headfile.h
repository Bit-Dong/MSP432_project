#ifndef _headfile_h
#define _headfile_h
#ifdef __cplusplus



extern "C"
{
#endif

#include <config.h>

//432������ͷ�ļ�
//#include <driverlib.h>
#include <ti/devices/msp432p4xx/driverlib/driverlib.h>
//����ͷ�ļ�
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
//����ģ��ͷ�ļ�
#include "dat.h"
#include "config.h"
#include "exinIIC.h"
#include "exinMPU6050.h"
#include "exinHC_SR04.h"
#include "motor.h"
#include "exinsystem.h"

#ifdef __cplusplus
}
#endif

#endif // __DRIVERLIB_GPIO_H__
