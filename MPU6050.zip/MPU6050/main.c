#include "sysinit.h"
#include "usart.h"
#include "timA.h"
#include "usart.h"
#include "delay.h"
#include "led.h"
#include "headfile.h"

#define CLKDIV 64   //时钟源分频
#define CCR0 60000  // 比较值0

/*
MPUS6050：SCL---P6.4   SDA---P6.5
*/
 
#define Gyrox_erro          -36   //x轴角速度误差
#define Gyroy_erro          -27   //y轴误差
#define Gyroz_erro          -37   //z轴误差
 
short MPU_ID,temp,gx,gy,gz,ax,ay,az;
float roll,yaw,pitch;
char txt[80];
int m=0;
 

void MPU_Low_fillter_Get_Angle()//低通滤波器解算数据
{
    float acc_roll,acc_pitch,acc_yaw;

    float a = 0.9;//互补滤波系数
    MPU_Get_Gyro(&gx,&gy,&gz);
    MPU_Get_Acc(&ax,&ay,&az);
    MPU_Get_Angel(ax,ay,az,&acc_roll,&acc_pitch,&acc_yaw);

    roll =(a*(roll+(gy-Gyroy_erro)*0.005)+(1-a)*acc_roll);//5ms
    pitch =(a*(pitch+(gx-Gyrox_erro)*0.005)+(1-a)*acc_pitch);//5ms
    yaw =((yaw+(gz-Gyroz_erro)*0.005));//5ms
}
	
int main(void)
{
    SysInit();  
	uart_init(115200);
	LED_Init();					 
	TimA0_Int_Init(CCR0,CLKDIV); 
	MPU_init();//MPU6050寄存器初始化
    delay_init(); 
    MAP_Interrupt_enableMaster(); // 开启总中断
    while (1)
    {
		MPU_Low_fillter_Get_Angle();	//pitch:俯仰角  roll:横滚角  yaw:航偏角
		printf("%.2f\r\n",pitch);    //Tips:字符串过长会出现卡死现象！ 且放在定时器中断里面也会出现卡死
    }
}

void TA0_0_IRQHandler(void)
{
    MAP_Timer_A_clearCaptureCompareInterrupt(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_0);
    
    MAP_GPIO_toggleOutputOnPin(GPIO_PORT_P1, GPIO_PIN0);

    
}
