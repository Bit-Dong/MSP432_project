#include "sysinit.h"
#include "delay.h"
#include "oled.h"
#include "bmp.h"

int main(void)
{
    SysInit();   
    delay_init(); 
    OLED_Init(); 

    while (1)
    {
        //显示字符串   0~128   0~6
        OLED_ShowString(54, 0, (uint8_t *)"CSDN", 16);
        OLED_ShowString(30, 2, (uint8_t *)"Bit_Dong", 16);

		OLED_ShowChar(60, 4, 'A', 16);	//显示字符
		OLED_ShowNum(55, 6, 666, 3, 16); //显示整数
	
        delay_ms(300);
        OLED_Clear(); //清屏
    }
}
