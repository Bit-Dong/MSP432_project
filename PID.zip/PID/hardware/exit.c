#include "exit.h"
#include "led.h"
#include "usart.h"
#include "oled.h"



void Exit_Init(void) 
{
	
	/*1. �����ⲿ�ж�*/
	GPIO_enableInterrupt(GPIO_PORT_P2, GPIO_PIN0);
	GPIO_enableInterrupt(GPIO_PORT_P2, GPIO_PIN1);
	GPIO_enableInterrupt(GPIO_PORT_P3, GPIO_PIN5);
	GPIO_enableInterrupt(GPIO_PORT_P3, GPIO_PIN7);
	/*2. �����˿��ж�*/
	Interrupt_enableInterrupt(INT_PORT2);
	Interrupt_enableInterrupt(INT_PORT3);
	/*3. ���ô�����ʽ*/
	GPIO_interruptEdgeSelect(GPIO_PORT_P2, GPIO_PIN0, GPIO_LOW_TO_HIGH_TRANSITION);
	GPIO_interruptEdgeSelect(GPIO_PORT_P2, GPIO_PIN1, GPIO_LOW_TO_HIGH_TRANSITION);
	GPIO_interruptEdgeSelect(GPIO_PORT_P3, GPIO_PIN5, GPIO_LOW_TO_HIGH_TRANSITION);
	GPIO_interruptEdgeSelect(GPIO_PORT_P3, GPIO_PIN7, GPIO_LOW_TO_HIGH_TRANSITION);
	/*4. ����Ϊ������������*/
	GPIO_setAsInputPin(GPIO_PORT_P2, GPIO_PIN0);
	GPIO_setAsInputPin(GPIO_PORT_P2, GPIO_PIN1);
	GPIO_setAsInputPin(GPIO_PORT_P3, GPIO_PIN5);
	GPIO_setAsInputPin(GPIO_PORT_P3, GPIO_PIN7);
	/*5. �����ж����ȼ�*/
	Interrupt_setPriority(INT_PORT2,1<<5);
	Interrupt_setPriority(INT_PORT3,1<<5);
	/*6. ����жϱ�־λ*/
	GPIO_clearInterrupt(GPIO_PORT_P2, GPIO_PIN0);
	GPIO_clearInterrupt(GPIO_PORT_P2, GPIO_PIN1);
	GPIO_clearInterrupt(GPIO_PORT_P3, GPIO_PIN7);
	GPIO_clearInterrupt(GPIO_PORT_P3, GPIO_PIN5);	
	/*7.�������ж� */
	Interrupt_enableMaster();
}


