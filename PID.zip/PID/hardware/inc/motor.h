
#ifndef __MOTOR_H
#define __MOTOR_H
#include <ti/devices/msp432p4xx/driverlib/driverlib.h>

void gpio_set_Asout(uint_fast8_t selectedPort,uint_fast16_t selectedPins);
void gpio_disable_Ren(uint_fast8_t selectedPort,uint_fast16_t selectedPins);
void gpio_init(uint_fast8_t selectedPort,uint_fast16_t selectedPins,int MODE,unsigned int out_value);
void gpio_enable_Ren(uint_fast8_t selectedPort,uint_fast16_t selectedPins);
void gpio_set_Low(uint_fast8_t selectedPort,uint_fast16_t selectedPins);
void gpio_set_High(uint_fast8_t selectedPort,uint_fast16_t selectedPins);
void gpio_set_Asin(uint_fast8_t selectedPort,uint_fast16_t selectedPins);

void Motor_Init(void);
void Forward(void);
void Stop(void);
void Left(void);
void Right(void);

#endif

