#ifndef __SG90_H
#define __SG90_H
#include <ti/devices/msp432p4xx/driverlib/driverlib.h>
#include "timA.h"
#include "delay.h"


void SG90_angle(int a);
void SG90_Cal(void);

#endif
