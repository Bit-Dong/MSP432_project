#include "sysinit.h"
#include "usart.h"
#include "timA.h"
#include "usart.h"
#include "led.h"
#include "motor.h"
#include "delay.h"
#include "oled.h"
#include "bmp.h"
#include "adc.h"
#include "key4x4.h"
#include "exit.h"
#include "key.h"
#include "sg90.h"
#include "pwm.h"
#include "bluetooth.h"
#include "PID.h"
#include "vofa.h"


#define CLKDIV0 48   //时钟源分频   Pwm
#define CLKDIV1 48   //时钟源分频   Timer 
#define CCR0 1000  // 比较值0
#define CCR1 10000  // 比较值1    5ms

/*
 * 定时器中断周期：
 *
 * T_timer_a = CLKDIV * (CCR0 + 1) / f_clk 
 *           = 64 * 37500 / 48000000 
 *           = 0.05s = 20Hz
 */
 
PID L_pid,R_pid;
int L_out,R_out;
int encoder_L = 0;
int encoder_R = 0;

int n=0;
 
u8 byte[4];
 
int main(void)
{
    SysInit(); 
	uart_init(115200); 	
	LED_Init();	
    delay_init(); 
    OLED_Init(); 
//	ADC_Config(); 
	Exit_Init();
	KEY_Init();
	//SG90_angle(0);
	Motor_Init();
	//BlueTooth_Init();
	PID_Init(&L_pid,0,3.15,0.36,10);
	PID_Init(&R_pid,0,3.15,0.36,10);

    TimA0_PWM_Init(CCR0,CLKDIV0);
	TimA1_Int_Init(CCR1,CLKDIV1);   //10ms    脉冲0-75
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           
	Forward();
//	MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 1000);
//	MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 0);
	
		//显示字符串   0~128   0~6
	OLED_ShowString(30, 0, (uint8_t *)"Bit_Dong", 16);
	PID_SetPoint(&L_pid,25);
	PID_SetPoint(&R_pid,25);

    while (1)
    {

		
    }
}


void TA1_0_IRQHandler(void)
{
	n++;
    MAP_Timer_A_clearCaptureCompareInterrupt(TIMER_A1_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_0);	
	
	L_out=Position_PID_Cal(&L_pid,encoder_L);
	R_out=Position_PID_Cal(&R_pid,encoder_R);
	MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, L_out);
	MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, R_out);
	//SendDatatoVoFA(byte,encoder_R);
	encoder_L=0;
	encoder_R=0;		

	
}




void PORT2_IRQHandler(void)
{
    uint16_t flag;

    /*获取中断状态*/
    flag = GPIO_getEnabledInterruptStatus(GPIO_PORT_P2);
    /*清除中断标志位*/
    GPIO_clearInterruptFlag(GPIO_PORT_P2, flag);

    /*左轮编码器线A*/
    if (flag & GPIO_PIN0)
    {
//        if (GPIO_getInputPinValue(GPIO_PORT_P2, GPIO_PIN1) == 0)
            encoder_L++;
//        else if (GPIO_getInputPinValue(GPIO_PORT_P2, GPIO_PIN1) == 1)
//            encoder_L--;
    }

    /*左轮编码器线B*/
    if (flag & GPIO_PIN1)
    {
//        if (GPIO_getInputPinValue(GPIO_PORT_P2, GPIO_PIN0) == 0)
//            encoder_L--;
//        else if (GPIO_getInputPinValue(GPIO_PORT_P2, GPIO_PIN0) == 1)
            encoder_L++;
    }
	
	
}

void PORT3_IRQHandler(void)
{
	  uint16_t flag;

    /*获取中断状态*/
    flag = GPIO_getEnabledInterruptStatus(GPIO_PORT_P3);
    /*清除中断标志位*/
    GPIO_clearInterruptFlag(GPIO_PORT_P3, flag);
	
		/*右轮编码器线A*/
    if (flag & GPIO_PIN5)
    {
//        if (GPIO_getInputPinValue(GPIO_PORT_P3, GPIO_PIN7) == 0)
            encoder_R++;
//        else if (GPIO_getInputPinValue(GPIO_PORT_P3, GPIO_PIN7) == 1)
//            encoder_R--;
    }

    /*右轮编码器线B*/
    if (flag & GPIO_PIN7)
    {
//        if (GPIO_getInputPinValue(GPIO_PORT_P3, GPIO_PIN5) == 0)
//            encoder_R--;
//        else if (GPIO_getInputPinValue(GPIO_PORT_P3, GPIO_PIN5) == 1)
            encoder_R++;
    }

}







