#include "timA.h"

/**************************************         TIMA0          *******************************************/

void TimA2_PWM_Init(uint16_t ccr0, uint16_t psc)
{
	    /*初始化引脚*/
    MAP_GPIO_setAsPeripheralModuleFunctionOutputPin(GPIO_PORT_P5, GPIO_PIN6, GPIO_PRIMARY_MODULE_FUNCTION);

    Timer_A_PWMConfig TimA2_PWMConfig;
    /*定时器PWM初始化*/
    TimA2_PWMConfig.clockSource = TIMER_A_CLOCKSOURCE_SMCLK;             //时钟源
    TimA2_PWMConfig.clockSourceDivider = psc;                            //时钟分频 范围1-64
    TimA2_PWMConfig.timerPeriod = ccr0;                                  //自动重装载值（ARR）
    TimA2_PWMConfig.compareRegister = TIMER_A_CAPTURECOMPARE_REGISTER_1; //通道二 （引脚定义）
    TimA2_PWMConfig.compareOutputMode = TIMER_A_OUTPUTMODE_TOGGLE_SET;   //输出模式                                  //这里是改变占空比的地方 默认100%

    MAP_Timer_A_generatePWM(TIMER_A2_BASE, &TimA2_PWMConfig); /* 初始化比较寄存器以产生 PWM1 */
	
}
