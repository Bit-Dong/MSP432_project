#include "sysinit.h"
#include "usart.h"
#include "timA.h"
#include "usart.h"
#include "led.h"
#include "motor.h"
#include "sg90.h"
#include "key.h"

#define CLKDIV 64   //时钟源分频
#define CCR0 20000  // 比较值0

/*
 * 定时器中断周期：
 *
 * T_timer_a = CLKDIV * (CCR0 + 1) / f_clk 
 *           = 64 * 37500 / 48000000 
 *           = 0.05s = 20Hz
 */
 
int main(void)
{
	int key;
	delay_init();
    SysInit();  			    
	LED_Init();					
	KEY_Init();
	TimA2_PWM_Init(20000,48);
	SG90_angle(0);
    while (1)
    {	
		SG90_Cal();
//		key=KEY_Scan(0);
//		if(key==KEY1_PRES)
//		{
//			LED_Y_On();
//			SG90_angle(180);
//		}			
//		else if(key==KEY2_PRES)
//		{
//			LED_W_On();
//			SG90_angle(0);
//		}		
    }
}


