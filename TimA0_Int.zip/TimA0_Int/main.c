#include "sysinit.h"
#include "usart.h"
#include "timA.h"
#include "usart.h"
#include "led.h"

#define CLKDIV 64   //时钟源分频
#define CCR0 60000  // 比较值0

/*
 * 定时器中断周期：
 *
 * T_timer_a = CLKDIV * (CCR0 + 1) / f_clk 
 *           = 64 * 37500 / 48000000 
 *           = 0.05s = 20Hz
 */
 
int main(void)
{
    SysInit();  			     
	LED_Init();					 
	TimA0_Int_Init(CCR0,CLKDIV); 
    
    MAP_Interrupt_enableMaster(); // 开启总中断
    while (1)
    {
    }
}


