#include "sysinit.h"
#include "usart.h"
#include "timA.h"
#include "usart.h"
#include "led.h"
#include "motor.h"

#define CLKDIV 64   //时钟源分频
#define CCR0 1000  // 比较值0

/*
 * 定时器中断周期：
 *
 * T_timer_a = CLKDIV * (CCR0 + 1) / f_clk 
 *           = 64 * 37500 / 48000000 
 *           = 0.05s = 20Hz
 */
 
int main(void)
{
    SysInit();  			    
	LED_Init();					
	gpio_init(GPIO_PORT_P6,GPIO_PIN4,0,0);
	gpio_init(GPIO_PORT_P6,GPIO_PIN5,0,1);
	gpio_init(GPIO_PORT_P6,GPIO_PIN0,0,0);
	gpio_init(GPIO_PORT_P6,GPIO_PIN1,0,1);
    TimA2_PWM_Init(CCR0,CLKDIV);
	MAP_Timer_A_setCompareValue(TIMER_A2_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 800);
	MAP_Timer_A_setCompareValue(TIMER_A2_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 400);
    while (1)
    {
			
		
    }
}


