#include "sysinit.h"
#include "usart.h"
#include "baudrate_calculate.h"
#include "key.h"
#include "led.h"
#include "tim32.h"

#define CLKDIV TIMER32_PRESCALER_1 // 时钟源分频
#define CLKDIV2 TIMER32_PRESCALER_16 // 时钟源分频 
#define ARR 47999999               // 自动重装载值

uint8_t key;

int main(void)
{
    /* Halting WDT  */
    MAP_WDT_A_holdTimer();
    SysInit();
    LED_Init();
	KEY_Init();
	
	uart_init(115200);
	printf("This is Timer32:\r\n");
	Tim32_0_Int_Init(ARR,CLKDIV);
	Tim32_1_Int_Init(ARR,CLKDIV2);
    while(1)
    {
		key = KEY_Scan(0);
        if (key == KEY1_PRES)
		{
			LED_RED_On();
			MAP_Interrupt_disableInterrupt(INT_T32_INT1);
			printf("\r\n\r\nTimer32_0 Fail!\r\n\r\n");
		}          
        else if (key == KEY2_PRES)
		{
			LED_RED_Off();
			MAP_Interrupt_enableInterrupt(INT_T32_INT1);
			printf("\r\n\r\nTimer32_0 Open!\r\n\r\n");
		}
            
    }
}




