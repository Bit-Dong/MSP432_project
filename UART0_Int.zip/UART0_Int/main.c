/******************************************************************************
// MSP432P401R
// 7 串口配置
// Bilibili：m-RNA
// E-mail:m-RNA@qq.com
// 创建日期:2021/8/25
*******************************************************************************/

/*
 * 2021/10/15 更新
 * 
 * 此版本支持 标准C库
 * 终于可以不使用微库啦
 *
 * 使用标准C库时，将无法使用scanf；
 * 如果需要使用scanf时，请使用微库 MicroLIB。
 * 
 */

#include "sysinit.h"
#include "usart.h"
#include "baudrate_calculate.h"
#include "key.h"
#include "led.h"

char c=0;
uint8_t key;

int main(void)
{
    /* Halting WDT  */
    MAP_WDT_A_holdTimer();

    //0.配置时钟
    SysInit();
	
    LED_Init();
	KEY_Init();
	
	UARTA0_Init();

	

    while(1)
    {
		key = KEY_Scan(0);
        if (key == KEY1_PRES)
            LED_RED_On();
        else if (key == KEY2_PRES)
            LED_RED_Off();
		
		if(c=='1') 
			LED_Y_On();
		else if(c=='a') 
			LED_P_On();
		
    }
}

//8.编写UART ISR
void EUSCIA0_IRQHandler(void)
{
    uint32_t status = UART_getEnabledInterruptStatus(EUSCI_A0_BASE);

    if(status & EUSCI_A_UART_RECEIVE_INTERRUPT_FLAG) //接收中断
    {
		c=MAP_UART_receiveData(EUSCI_A0_BASE);
        UART_transmitData(EUSCI_A0_BASE, c); //发送数据
    }

}




