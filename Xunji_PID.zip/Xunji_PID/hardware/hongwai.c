#include "hongwai.h"
#include "motor.h"


void HongWai_Init(void)
{
	gpio_init(GPIO_PORT_P10, GPIO_PIN1,1,1);   //��ʼ�� Ϊ����ģʽ����Ĭ��Ϊ�ߵ�ƽ
	gpio_init(GPIO_PORT_P10, GPIO_PIN2,1,1);
	gpio_init(GPIO_PORT_P10, GPIO_PIN3,1,1);
	gpio_init(GPIO_PORT_P10, GPIO_PIN4,1,1);
	gpio_init(GPIO_PORT_P10, GPIO_PIN5,1,1);	
}

