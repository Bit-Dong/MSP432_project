#include "sysinit.h"
#include "usart.h"
#include "timA.h"
#include "usart.h"
#include "led.h"
#include "motor.h"
#include "delay.h"
#include "oled.h"
#include "bmp.h"
#include "adc.h"
#include "key4x4.h"
#include "exit.h"
#include "key.h"
#include "sg90.h"
#include "pwm.h"
#include "bluetooth.h"
#include "PID.h"
#include "vofa.h"
#include "hongwai.h"
#include "openmv.h"

/*                           MSP432P401R
 *
 *	Uart0:		 P1.2(RX)			   P1.3(TX)	
 *	Motor:		 P6.4、P6.5(左)        P6.0、P6.1(右) 
 *	PWM：  		 P2.4(左)			   P2.5(右)       		    -----  TA0 CH0~CH1
 *  A/B相：		 P5.6(左)	   	       P5.7(右)          		-----  TA2 CH0~CH1
 *  BlueTooth：  P2.2(RX)			   P2.3(TX)					-----  Uart1
 *	OLED:		 P1.7(SCL)			   P1.6(SDA)				-----  IIC
 *  ADC14:		 P5.5、P5.4、P5.3								-----  CH0~CH2   
 *  OpenMV:		 P3.2(RX)			   P3.3(TX)					-----  Uart2
 *  HongWai:	 P10.1	 P10.2	 P10.3   P10.4   P10.5			-----  OUT1~OUT5 
 */



#define CLKDIV0 48   //时钟源分频   Pwm
#define CLKDIV1 48   //时钟源分频   Timer 
#define CCR0 1000  // 比较值0
#define CCR1 10000  // 比较值1    10ms

#define z 2*3.1415926*0.0325    //轮子周长
#define cn 1170              //轮子转动一圈电机输出的脉冲数  13*45*2     单相2倍频计数
#define j z/cn

 /*
	车轮直径65mm 
	减速比 1：45   轮子转一圈，电机转45圈  
	电机转一圈单相输出13个脉冲
 */
 
PID L_pid,R_pid;
int L_out,R_out;
int encoder_L = 0;
int encoder_R = 0;

int n=0;
double m=j;    //脉冲数
double s=0,v=0,sum=0;    //路程、速度
u8 byte[4];
int sum_flag=0,openmv_rxflag;
char openmv_rx;
int l1,l2,l3,l4,l5;

int main(void)
{
    SysInit(); 
	uart_init(115200); 	
	LED_Init();	
    delay_init(); 
    OLED_Init(); 
//	ADC_Config(); 
	//Exit_Init();
	KEY_Init();
	Motor_Init();
	HongWai_Init();
	//BlueTooth_Init();
	//OpenMV_Init();
	PID_Init(&L_pid,0,10,0.3,5);
	PID_Init(&R_pid,0,10,0.3,5);

	TimA2_Cap_Init();
    TimA0_PWM_Init(CCR0,CLKDIV0);
	TimA1_Int_Init(CCR1,CLKDIV1);   //10ms    脉冲0-75
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           
	Forward();
//	MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, 1000);
//	MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, 0);
	
		//显示字符串   0~128   0~6
	OLED_ShowString(30, 0, (uint8_t *)"Bit_Dong", 16);
	PID_SetPoint(&L_pid,15);
	PID_SetPoint(&R_pid,15);

    while (1)
    {
		l1=gpio_get(GPIO_PORT_P10, GPIO_PIN1);
		l2=gpio_get(GPIO_PORT_P10, GPIO_PIN2);
		l3=gpio_get(GPIO_PORT_P10, GPIO_PIN3);
		l4=gpio_get(GPIO_PORT_P10, GPIO_PIN4);
		l5=gpio_get(GPIO_PORT_P10, GPIO_PIN5);
		
		if(l1==1 && l2==1 && l3==0 && l4==1 && l5==1)
		{
			PID_SetPoint(&L_pid,15);
			PID_SetPoint(&R_pid,15);		
		}
		else if(l1==1 && l2==0 && l3==1 && l4==1 && l5==1)
		{
			PID_SetPoint(&L_pid,4);
			PID_SetPoint(&R_pid,20);			
		}
		else if(l1==0 && l2==1 && l3==1 && l4==1 && l5==1)
		{
			PID_SetPoint(&L_pid,5);
			PID_SetPoint(&R_pid,30);			
		}		
		else if(l1==1 && l2==1 && l3==1 && l4==0 && l5==1)
		{
			PID_SetPoint(&L_pid,20);
			PID_SetPoint(&R_pid,4);			
		}
		else if(l1==1 && l2==1 && l3==1 && l4==1 && l5==0)
		{
			PID_SetPoint(&L_pid,30);
			PID_SetPoint(&R_pid,5);			
		}

    }
}


void TA1_0_IRQHandler(void)
{
	n++;
    MAP_Timer_A_clearCaptureCompareInterrupt(TIMER_A1_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_0);	
	
	L_out=Position_PID_Cal(&L_pid,encoder_L);
	s=encoder_L*m;
	v=s*100;      // v=s/t   t=10ms=0.01s
	sum+=s;
//	if(n%100==0)
//	{
//		printf("\r\n encoder:%d  ---  sum: %f m   ---   v:%f m/s\r\n",encoder_L,sum,v);
//	}
	R_out=Position_PID_Cal(&R_pid,encoder_R);
	MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, L_out);
	MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, R_out);
	//SendDatatoVoFA(byte,encoder_R);
	encoder_L=0;
	encoder_R=0;		

	
}


void TA2_N_IRQHandler(void)
{
    uint_fast16_t status = MAP_Timer_A_getCaptureCompareEnabledInterruptStatus(TIMER_A2_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1);
    if (status & TIMER_A_CAPTURECOMPARE_INTERRUPT_FLAG)
    {
        encoder_L++; // 每次捕获增加编码器计数值
		
        MAP_Timer_A_clearCaptureCompareInterrupt(TIMER_A2_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1);
    }
	
	uint_fast16_t status2 = MAP_Timer_A_getCaptureCompareEnabledInterruptStatus(TIMER_A2_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2);
    if (status2 & TIMER_A_CAPTURECOMPARE_INTERRUPT_FLAG)
    {
        encoder_R++; // 每次捕获增加编码器计数值

        MAP_Timer_A_clearCaptureCompareInterrupt(TIMER_A2_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2);
    }
}

//BlueTooth接收中断
void EUSCIA1_IRQHandler(void)
{
    uint32_t status = UART_getEnabledInterruptStatus(EUSCI_A1_BASE);

    if(status & EUSCI_A_UART_RECEIVE_INTERRUPT_FLAG) //接收中断
    {
		MAP_UART_receiveData(EUSCI_A1_BASE);
		//UART_transmitData(EUSCI_A1_BASE, 'b'); //发送数据
		//UART_enableInterrupt(EUSCI_A1_BASE, EUSCI_A_UART_RECEIVE_INTERRUPT);    //开启接收中断 
        //UART_disableInterrupt(EUSCI_A1_BASE, EUSCI_A_UART_RECEIVE_INTERRUPT);   //关闭接收中断
    }

}


//OpenMV接收中断
void EUSCIA2_IRQHandler(void)
{
    uint32_t status = UART_getEnabledInterruptStatus(EUSCI_A2_BASE);

    if(status & EUSCI_A_UART_RECEIVE_INTERRUPT_FLAG) //接收中断
    {
		openmv_rx=MAP_UART_receiveData(EUSCI_A2_BASE);
        if(openmv_rx=='1')
		{
			openmv_rxflag=1;
		}
		if(openmv_rx=='2')
		{
			openmv_rxflag=2;
		}
        if(openmv_rx=='3')
		{
			openmv_rxflag=3;
		}
        if(openmv_rx=='4')
		{
			openmv_rxflag=4;
		}
        if(openmv_rx=='5')
		{
			openmv_rxflag=5;
		}
		//OLED_ShowChar(60,2,openmv_rx,16);
		UART_disableInterrupt(EUSCI_A2_BASE, EUSCI_A_UART_RECEIVE_INTERRUPT);   //关闭接收中断
    }
	
}

