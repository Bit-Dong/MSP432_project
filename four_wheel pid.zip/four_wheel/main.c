#include "sysinit.h"
#include "usart.h"
#include "timA.h"
#include "usart.h"
#include "led.h"
#include "motor.h"
#include "delay.h"
#include "oled.h"
#include "bmp.h"
#include "adc.h"
#include "key4x4.h"
#include "exit.h"
#include "key.h"
#include "sg90.h"
#include "pwm.h"
#include "bluetooth.h"
#include "PID.h"
#include "vofa.h"
#include "hongwai.h"
#include "openmv.h"
#include "beep.h"
#include "gy56.h"

/*                           MSP432P401R
 *
 *	Beep：		 P10.1
 *	Motor:		 P6.4、P6.5(左前)  P4.4、P4.5(左后)   P6.0、P6.1(右前) P4.0、P4.1(右后) 
 *	OLED:		 P1.7(SCL)			   P1.6(SDA)									-----  IIC
 *	PWM：  		 P2.4(左前) P2.6(左后)	P2.5(右前) P2.7(右后)       		   		-----  TA0 CH0~CH1 
 *  A/B相：		 P5.6(左前)	P6.6(左后)  P5.7(右前) P6.7(右后)            			-----  TA2 CH0~CH1
 *  ADC14:		 P5.5、P5.4、P5.3(该项目未使用)										-----  ADC CH0~CH2  
 *	Vofa:		 P1.2(RX)			   P1.3(TX)										-----  Uart0
 *  BlueTooth：  P2.2(RX)			   P2.3(TX)										-----  Uart1 
 *  OpenMV：	 P3.2(RX)			   P3.3(TX)										-----  Uart2
 *  GY56:		 P9.6(RX)			   P9.7(TX)										-----  Uart3
 *  HongWai:	 P8.6 P8.7 P9.1 P8.3 P5.3 P9.3 P6.3 P7.2 P7.0 P9.5 P7.5 P7.7		-----  OUT1~OUT12(左-右)
 *
 */

#define CLKDIV0 48   //时钟源分频   Pwm
#define CLKDIV1 48   //时钟源分频   Timer 
#define CCR0 20000  // 比较值0
#define CCR1 10000  // 比较值1    10ms
#define z 2*3.1415926*0.0325    //轮子周长 0.204203519
#define cn 780             //轮子转动一圈电机输出的脉冲数  13*30*2     单相2倍频计数
#define j z/cn             //每个脉冲走的距离


void Xunji(void); 

uint8_t key;  			//按键检测
u8 byte[4];      		//vofa
double Timer=0;  		//运行时间
int n=0;		 		//定时器溢出次数
double m=j;      		//脉冲数
double s=0,v=0,sum=0;   //每次定时器溢出走的距离、速度、总路程
int steer=0;			//舵机转向角度
char openmv_rx;    		//OpenMV接收字符
int distance=0;			//gy56测量的距离	



//PID相关
PID L1_pid,R1_pid,L2_pid,R2_pid;
int encoder_L1=0,encoder_L2=0;     //左轮实际触发的脉冲数
int encoder_R1=0,encoder_R2=0;	   //右轮实际触发的脉冲数
float target_L1=0,target_L2=0;	   //左轮目标值（脉冲）
float target_R1=0,target_R2=0;	   //右轮目标值（脉冲）
int L1_out,R1_out,L2_out,R2_out;	   //pid计算返回值

int main(void)
{
    SysInit(); 
	uart_init(115200); 
	LED_Init();	
	Beep_Init();
    delay_init(); 
    //OLED_Init(); 
	KEY_Init();
	Motor_Init();
	BlueTooth_Init();
	OpenMV_Init();
	HongWai_Init();
	TimA1_Int_Init(CCR1,CLKDIV1);
	TimA2_Cap_Init();
    TimA0_PWM_Init(CCR0,CLKDIV0);
	GY56_Init();
	gy56_send_com(0x76,1);   //发送连续输出指令
	Forward();
	PID_Init(&L1_pid,10,20,30,0);     //0~26
	PID_Init(&L2_pid,10,20,30,0);     
	PID_Init(&R1_pid,10,20,30,0);
	PID_Init(&R2_pid,10,20,30,0);
	
	
    while (1)
    {						

	}
}



void TA1_0_IRQHandler(void)
{
    MAP_Timer_A_clearCaptureCompareInterrupt(TIMER_A1_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_0);	
	n++;
	Timer=0.01*n;
	s=(encoder_L1+encoder_R1)/2*m;
//	v=s*100;      // v=s/t   t=10ms=0.01s
	sum+=s;	
	//Send_FourDatatoVoFA(byte,encoder_L1,encoder_L2,encoder_R1,encoder_R2);
	//SendData(byte,encoder_L);
	L1_out=Position_PID_Cal(&L1_pid,encoder_L1);  //左前
	R1_out=Position_PID_Cal(&R1_pid,encoder_R1);  //右前
	L2_out=Position_PID_Cal(&L2_pid,encoder_L2);  
	R2_out=Position_PID_Cal(&R2_pid,encoder_R2);
	MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1, L1_out);
	MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2, R1_out);
	MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_3, L2_out);
	MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_4, R2_out);
	encoder_L1=0;
	encoder_R1=0;	
	encoder_L2=0;
	encoder_R2=0;	
}

void TA2_N_IRQHandler(void)
{
    uint_fast16_t status = MAP_Timer_A_getCaptureCompareEnabledInterruptStatus(TIMER_A2_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1);
    if (status & TIMER_A_CAPTURECOMPARE_INTERRUPT_FLAG)
    {
		encoder_L1++;
        MAP_Timer_A_clearCaptureCompareInterrupt(TIMER_A2_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_1);
    }
	
	uint_fast16_t status2 = MAP_Timer_A_getCaptureCompareEnabledInterruptStatus(TIMER_A2_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2);
    if (status2 & TIMER_A_CAPTURECOMPARE_INTERRUPT_FLAG)
    {
		encoder_R1++;
        MAP_Timer_A_clearCaptureCompareInterrupt(TIMER_A2_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_2);
    }
	
    uint_fast16_t status3 = MAP_Timer_A_getCaptureCompareEnabledInterruptStatus(TIMER_A2_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_3);
    if (status3 & TIMER_A_CAPTURECOMPARE_INTERRUPT_FLAG)
    {
		encoder_L2++;
        MAP_Timer_A_clearCaptureCompareInterrupt(TIMER_A2_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_3);
    }
	
	uint_fast16_t status4 = MAP_Timer_A_getCaptureCompareEnabledInterruptStatus(TIMER_A2_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_4);
    if (status4 & TIMER_A_CAPTURECOMPARE_INTERRUPT_FLAG)
    {
		encoder_R2++;
        MAP_Timer_A_clearCaptureCompareInterrupt(TIMER_A2_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_4);
    }
	
}



//OpenMV
void EUSCIA2_IRQHandler(void)
{
    uint32_t status = UART_getEnabledInterruptStatus(EUSCI_A2_BASE);   //获取中断状态

    if(status & EUSCI_A_UART_RECEIVE_INTERRUPT_FLAG) 		//接收中断
    {
//		openmv_rx=MAP_UART_receiveData(EUSCI_A2_BASE);//接收数据
//		UART_transmitData(EUSCI_A2_BASE, 'z'); //发送数据
    }
//	UART_disableInterrupt(EUSCI_A2_BASE, EUSCI_A_UART_RECEIVE_INTERRUPT);   //关闭接收中断
//	UART_enableInterrupt(EUSCI_A2_BASE, EUSCI_A_UART_RECEIVE_INTERRUPT);    //开启接收中断 
}

void Xunji(void)  
{

	
}
