#include "hongwai.h"
#include "motor.h"


void HongWai_Init(void)
{
	gpio_init(GPIO_PORT_P10,GPIO_PIN5,1,1);   //��ײ����ʼ��
	
	gpio_init(GPIO_PORT_P8,GPIO_PIN6,1,1);   //��ʼ��P36��P37Ϊ����ģʽ����Ĭ��Ϊ�ߵ�ƽ
	gpio_init(GPIO_PORT_P8,GPIO_PIN7,1,1);
	gpio_init(GPIO_PORT_P9,GPIO_PIN1,1,1);
	gpio_init(GPIO_PORT_P8,GPIO_PIN3,1,1);
	gpio_init(GPIO_PORT_P5,GPIO_PIN3,1,1);
	gpio_init(GPIO_PORT_P9,GPIO_PIN3,1,1);
	gpio_init(GPIO_PORT_P6,GPIO_PIN3,1,1);	
	gpio_init(GPIO_PORT_P7,GPIO_PIN2,1,1);
	gpio_init(GPIO_PORT_P7,GPIO_PIN0,1,1);
	gpio_init(GPIO_PORT_P9,GPIO_PIN5,1,1);
//	gpio_init(GPIO_PORT_P9,GPIO_PIN7,1,1);
	gpio_init(GPIO_PORT_P7,GPIO_PIN5,1,1);	
	gpio_init(GPIO_PORT_P7,GPIO_PIN7,1,1);
	
	
}

