#ifndef __EXIT_H
#define __EXIT_H
#include <ti/devices/msp432p4xx/driverlib/driverlib.h>


void Exit_Init(void);       //IO��ʼ��


#endif
