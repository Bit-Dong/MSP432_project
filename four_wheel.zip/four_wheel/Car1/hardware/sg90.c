#include "sg90.h"
#include "delay.h"
/*
                20msΪ��
        0.5ms ------------ 0�ȣ�
        1.0ms ------------ 45�ȣ�
        1.5ms ------------ 90�ȣ�
        2.0ms ------------ 135�ȣ�
        2.5ms ------------ 180�ȣ�
*/

void SG90_angle(int a)
{
    int pwm=500+2000/180*a;
    MAP_Timer_A_setCompareValue(TIMER_A0_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_3, pwm);
} 


void SG90_Cal(void)
{
    int i=0,j=0;
    for(i=0;i<=180;i++)
    {
		delay_ms(3);
        SG90_angle(i);
    }
    for(j=180;j>=0;j--)
    {
		delay_ms(3);
        SG90_angle(j);
    }
}

